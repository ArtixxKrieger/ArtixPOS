<?php
define('POS_ACCESS', true);

// Error handling - return JSON for all errors
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $errstr,
        'debug' => 'File: ' . basename($errfile) . ' Line: ' . $errline
    ]);
    exit;
});

try {
    require_once 'config.php';
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database initialization failed',
        'debug' => $e->getMessage()
    ]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$input = getInput();

try {
    $db = getDB();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed',
        'debug' => $e->getMessage()
    ]);
    exit;
}

switch ($method) {
    case 'POST':
        $action = $input['action'] ?? '';
        
        switch ($action) {
            case 'login':
                handleLogin($db, $input);
                break;
                
            case 'register':
                handleRegister($db, $input);
                break;
                
            case 'logout':
                handleLogout($db, $input);
                break;
                
            case 'verify':
                handleVerify($db);
                break;
                
            case 'refresh':
                handleRefresh($db, $input);
                break;
                
            default:
                jsonResponse(false, null, 'Invalid action');
        }
        break;
        
    default:
        jsonResponse(false, null, 'Method not allowed');
}

$db->close();

/**
 * Handle user login
 */
function handleLogin($db, $input) {
    $email = strtolower(trim($input['email'] ?? ''));
    $password = $input['password'] ?? '';
    $remember = $input['remember'] ?? false;
    $ip = $_SERVER['REMOTE_ADDR'];
    
    if (empty($email) || empty($password)) {
        jsonResponse(false, null, 'Email and password required');
    }
    
    // Check rate limiting
    checkRateLimit($db, $ip);
    
    // Find user
    $stmt = $db->prepare('SELECT * FROM users WHERE email = :email AND is_active = 1');
    $stmt->bindValue(':email', $email);
    $result = $stmt->execute();
    $user = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$user || !password_verify($password, $user['password_hash'])) {
        recordFailedLogin($db, $ip);
        jsonResponse(false, null, 'Invalid email or password');
    }
    
    // Clear failed attempts
    clearLoginAttempts($db, $ip);
    
    // Update last login
    $stmt = $db->prepare('UPDATE users SET last_login = datetime("now") WHERE id = :id');
    $stmt->bindValue(':id', $user['id']);
    $stmt->execute();
    
    // Create session token
    $token = generateToken();
    $expires = $remember ? date('Y-m-d H:i:s', time() + 86400 * 30) : date('Y-m-d H:i:s', time() + 86400);
    
    $stmt = $db->prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (:token, :user_id, :expires)');
    $stmt->bindValue(':token', $token);
    $stmt->bindValue(':user_id', $user['id']);
    $stmt->bindValue(':expires', $expires);
    $stmt->execute();
    
    // Get user settings
    $stmt = $db->prepare('SELECT * FROM user_settings WHERE user_id = :id');
    $stmt->bindValue(':id', $user['id']);
    $result = $stmt->execute();
    $settings = $result->fetchArray(SQLITE3_ASSOC) ?: [];
    
    unset($user['password_hash']);
    
    jsonResponse(true, [
        'token' => $token,
        'expires' => $expires,
        'user' => $user,
        'settings' => $settings
    ], 'Login successful');
}

/**
 * Handle user registration (admin only)
 */
function handleRegister($db, $input) {
    // Verify admin
    $currentUser = getCurrentUser($db);
    if (!$currentUser || $currentUser['role'] !== 'admin') {
        jsonResponse(false, null, 'Unauthorized');
    }
    
    $email = strtolower(trim($input['email'] ?? ''));
    $password = $input['password'] ?? '';
    $name = trim($input['name'] ?? '');
    $storeName = trim($input['store_name'] ?? 'My Store');
    
    if (empty($email) || empty($password) || empty($name)) {
        jsonResponse(false, null, 'Email, password, and name required');
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, null, 'Invalid email format');
    }
    
    if (strlen($password) < 6) {
        jsonResponse(false, null, 'Password must be at least 6 characters');
    }
    
    // Check if email exists
    $stmt = $db->prepare('SELECT id FROM users WHERE email = :email');
    $stmt->bindValue(':email', $email);
    $result = $stmt->execute();
    if ($result->fetchArray()) {
        jsonResponse(false, null, 'Email already registered');
    }
    
    // Create user
    $userId = generateId();
    $passwordHash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    
    $stmt = $db->prepare('INSERT INTO users (id, email, password_hash, name, store_name, role) 
                          VALUES (:id, :email, :password, :name, :store, :role)');
    $stmt->bindValue(':id', $userId);
    $stmt->bindValue(':email', $email);
    $stmt->bindValue(':password', $passwordHash);
    $stmt->bindValue(':name', $name);
    $stmt->bindValue(':store', $storeName);
    $stmt->bindValue(':role', 'client');
    
    if ($stmt->execute()) {
        // Create default settings
        $stmt = $db->prepare('INSERT INTO user_settings (user_id) VALUES (:id)');
        $stmt->bindValue(':id', $userId);
        $stmt->execute();
        
        jsonResponse(true, ['id' => $userId], 'Client created successfully');
    } else {
        jsonResponse(false, null, 'Failed to create client');
    }
}

/**
 * Handle logout
 */
function handleLogout($db, $input) {
    $token = $input['token'] ?? '';
    
    if ($token) {
        $stmt = $db->prepare('DELETE FROM sessions WHERE token = :token');
        $stmt->bindValue(':token', $token);
        $stmt->execute();
    }
    
    jsonResponse(true, null, 'Logged out successfully');
}

/**
 * Verify current session
 */
function handleVerify($db) {
    $user = getCurrentUser($db);
    
    if ($user) {
        // Get user settings
        $stmt = $db->prepare('SELECT * FROM user_settings WHERE user_id = :id');
        $stmt->bindValue(':id', $user['id']);
        $result = $stmt->execute();
        $settings = $result->fetchArray(SQLITE3_ASSOC) ?: [];
        
        jsonResponse(true, [
            'user' => $user,
            'settings' => $settings
        ]);
    } else {
        jsonResponse(false, null, 'Session expired');
    }
}

/**
 * Refresh session token
 */
function handleRefresh($db, $input) {
    $token = $input['token'] ?? '';
    $remember = $input['remember'] ?? false;
    
    if (empty($token)) {
        jsonResponse(false, null, 'Token required');
    }
    
    // Verify token exists
    $stmt = $db->prepare('SELECT user_id FROM sessions WHERE token = :token AND expires_at > datetime("now")');
    $stmt->bindValue(':token', $token);
    $result = $stmt->execute();
    $session = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$session) {
        jsonResponse(false, null, 'Invalid or expired token');
    }
    
    // Extend expiration
    $newExpires = $remember ? date('Y-m-d H:i:s', time() + 86400 * 30) : date('Y-m-d H:i:s', time() + 86400);
    
    $stmt = $db->prepare('UPDATE sessions SET expires_at = :expires WHERE token = :token');
    $stmt->bindValue(':expires', $newExpires);
    $stmt->bindValue(':token', $token);
    $stmt->execute();
    
    jsonResponse(true, ['expires' => $newExpires], 'Token refreshed');
}
?>
