<?php
define('POS_ACCESS', true);
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = getInput();
$db = getDB();

// Verify user is logged in
$currentUser = getCurrentUser($db);
if (!$currentUser) {
    jsonResponse(false, null, 'Unauthorized - Please login');
}

$userId = $currentUser['id'];

switch ($method) {
    case 'GET':
        // Get user settings
        $stmt = $db->prepare('SELECT * FROM user_settings WHERE user_id = :user_id');
        $stmt->bindValue(':user_id', $userId);
        $result = $stmt->execute();
        $settings = $result->fetchArray(SQLITE3_ASSOC);
        
        if (!$settings) {
            // Create default settings
            $stmt = $db->prepare('INSERT INTO user_settings (user_id) VALUES (:user_id)');
            $stmt->bindValue(':user_id', $userId);
            $stmt->execute();
            
            $settings = [
                'currency' => '₱',
                'tax_rate' => 0,
                'address' => '',
                'phone' => '',
                'email_contact' => '',
                'receipt_footer' => 'Thank you for your business!'
            ];
        }
        
        // Add store name from users table
        $settings['store_name'] = $currentUser['store_name'];
        
        jsonResponse(true, $settings);
        break;

    case 'PUT':
    case 'POST':
        // Update settings
        $allowedFields = ['currency', 'tax_rate', 'address', 'phone', 'email_contact', 'receipt_footer'];
        
        $updates = [];
        foreach ($allowedFields as $field) {
            if (isset($input[$field])) {
                $updates[$field] = $input[$field];
            }
        }
        
        if (!empty($updates)) {
            $setParts = [];
            foreach ($updates as $key => $value) {
                $setParts[] = "$key = :$key";
            }
            
            $sql = 'UPDATE user_settings SET ' . implode(', ', $setParts) . ' WHERE user_id = :user_id';
            $stmt = $db->prepare($sql);
            
            foreach ($updates as $key => $value) {
                $stmt->bindValue(":$key", $value);
            }
            $stmt->bindValue(':user_id', $userId);
            $stmt->execute();
        }
        
        // Update store name if provided
        if (isset($input['store_name'])) {
            $stmt = $db->prepare('UPDATE users SET store_name = :store_name WHERE id = :user_id');
            $stmt->bindValue(':store_name', $input['store_name']);
            $stmt->bindValue(':user_id', $userId);
            $stmt->execute();
        }
        
        jsonResponse(true, null, 'Settings updated');
        break;

    default:
        jsonResponse(false, null, 'Method not allowed');
}

$db->close();
?>
