# Mobile POS System

A comprehensive Point of Sale web application designed for mobile devices with offline support, real-time sync, and sales analytics.

## Features

### Core POS Features
- **Product Management**: Add, edit, delete products with SKU, barcode, price, cost, stock, and category
- **Quick Search**: Search products by name, SKU, or barcode
- **Shopping Cart**: Add/remove items, adjust quantities, apply discounts
- **Checkout**: Multiple payment methods (Cash, Card, Mobile), calculate change
- **Receipt Generation**: Printable receipts with store branding
- **Sales History**: View all past transactions with details

### Advanced Features
- **Day/Night Mode**: Toggle between light and dark themes
- **Fully Responsive**: Optimized for mobile devices
- **AJAX Operations**: All buttons work asynchronously
- **Offline Mode**: Continue selling even without internet
- **Auto Sync**: Automatically sync data when connection is restored
- **Sales Analytics**: View sales by period (today, yesterday, week, month)
- **Data Persistence**: Local storage with PHP backend sync
- **PWA Support**: Install as a standalone app on mobile devices

## Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Backend**: PHP 7.4+
- **Storage**: LocalStorage (client) + JSON files (server)
- **PWA**: Service Worker, Web App Manifest

## Installation

### Requirements
- PHP 7.4 or higher
- Web server (Apache/Nginx)
- HTTPS (recommended for PWA features)

### Setup

1. **Upload files to your web server**
   ```
   /var/www/html/pos/
   ├── api/              # PHP API endpoints
   ├── assets/           # CSS, JS, icons
   ├── data/             # JSON data storage (auto-created)
   ├── index.html        # Main app
   ├── manifest.json     # PWA manifest
   ├── sw.js             # Service Worker
   └── README.md         # This file
   ```

2. **Set permissions**
   ```bash
   chmod 755 /var/www/html/pos/
   chmod 777 /var/www/html/pos/data/
   ```

3. **Configure (optional)**
   - Edit `api/config.php` to change data directory if needed

4. **Access the app**
   - Open `https://yourdomain.com/pos/` in a mobile browser
   - Add to home screen for standalone app experience

## Usage

### Getting Started

1. **First Launch**
   - The app will load with sample data
   - Go to Settings to configure your store name, currency, tax rate

2. **Adding Products**
   - Navigate to Products page
   - Click "Add Product" button
   - Fill in product details (name, price, stock, etc.)
   - Save

3. **Making a Sale**
   - On POS page, search or browse products
   - Tap a product to add to cart
   - Adjust quantities as needed
   - Apply discount if needed
   - Click "Checkout"
   - Select payment method and complete sale

4. **Viewing Analytics**
   - Go to Analytics page
   - Select time period (Today, Yesterday, Week, Month)
   - View sales, revenue, profit, and top products

### Offline Mode

The app works seamlessly offline:
- All data is stored locally
- Sales continue to work without internet
- Data syncs automatically when connection is restored
- Visual indicator shows online/offline status

### Keyboard Shortcuts

- **Search**: Focus on search bar automatically
- **Checkout**: Tap checkout button or swipe cart panel

## File Structure

```
pos-webapp/
├── api/
│   ├── config.php      # Configuration and helpers
│   ├── products.php    # Product CRUD API
│   ├── sales.php       # Sales and analytics API
│   ├── settings.php    # Store settings API
│   └── sync.php        # Data synchronization API
├── assets/
│   ├── css/
│   │   └── style.css   # All styles (mobile-first)
│   ├── js/
│   │   └── app.js      # Main application logic
│   └── icons/          # PWA icons
├── data/               # JSON data files (auto-created)
├── index.html          # Main application
├── manifest.json       # PWA manifest
├── sw.js               # Service Worker
└── README.md           # Documentation
```

## API Endpoints

### Products
- `GET api/products.php` - List all products
- `GET api/products.php?id={id}` - Get single product
- `GET api/products.php?search={query}` - Search products
- `POST api/products.php` - Create product
- `PUT api/products.php?id={id}` - Update product
- `DELETE api/products.php?id={id}` - Delete product

### Sales
- `GET api/sales.php` - List sales
- `GET api/sales.php?analytics=1&period={period}` - Get analytics
- `POST api/sales.php` - Create sale
- `DELETE api/sales.php?id={id}` - Delete sale

### Settings
- `GET api/settings.php` - Get settings
- `PUT api/settings.php` - Update settings

### Sync
- `GET api/sync.php` - Get all data for sync
- `POST api/sync.php` - Push pending changes

## Browser Support

- Chrome/Edge 80+
- Safari 13+
- Firefox 75+
- Samsung Internet 12+

## Security Notes

- This is a basic POS system for small businesses
- For production use, consider adding:
  - User authentication
  - HTTPS enforcement
  - Input validation and sanitization
  - Database instead of JSON files
  - Regular backups

## License

MIT License - Free for personal and commercial use

## Support

For issues or feature requests, please contact the developer.

---

**Mobile POS v1.0** - Built for small businesses
