<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = getInput();

switch ($method) {
    case 'GET':
        // Get all data for sync
        $products = readJson(PRODUCTS_FILE);
        $sales = readJson(SALES_FILE);
        $settings = readJson(SETTINGS_FILE);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'products' => $products,
                'sales' => $sales,
                'settings' => $settings,
                'sync_time' => date('Y-m-d H:i:s')
            ]
        ]);
        break;

    case 'POST':
        // Sync offline data
        $response = ['success' => true, 'synced' => [], 'errors' => []];
        
        // Sync pending sales
        if (isset($input['pending_sales']) && is_array($input['pending_sales'])) {
            $sales = readJson(SALES_FILE);
            $products = readJson(PRODUCTS_FILE);
            
            foreach ($input['pending_sales'] as $pendingSale) {
                try {
                    // Process sale similar to sales.php POST
                    $items = $pendingSale['items'] ?? [];
                    if (empty($items)) continue;
                    
                    $subtotal = 0;
                    $totalCost = 0;
                    $processedItems = [];
                    
                    foreach ($items as $item) {
                        $productId = $item['product_id'] ?? '';
                        $quantity = intval($item['quantity'] ?? 1);
                        
                        $product = null;
                        foreach ($products as $p) {
                            if ($p['id'] === $productId) {
                                $product = $p;
                                break;
                            }
                        }
                        
                        if ($product) {
                            $itemTotal = $product['price'] * $quantity;
                            $itemCost = ($product['cost'] ?? 0) * $quantity;
                            $subtotal += $itemTotal;
                            $totalCost += $itemCost;
                            
                            $processedItems[] = [
                                'product_id' => $productId,
                                'name' => $product['name'],
                                'price' => $product['price'],
                                'cost' => $product['cost'] ?? 0,
                                'quantity' => $quantity,
                                'total' => $itemTotal
                            ];
                            
                            // Update stock
                            foreach ($products as &$p) {
                                if ($p['id'] === $productId) {
                                    $p['stock'] = max(0, $p['stock'] - $quantity);
                                    $p['updated_at'] = date('Y-m-d H:i:s');
                                    break;
                                }
                            }
                        }
                    }
                    
                    $taxRate = floatval($pendingSale['tax_rate'] ?? 0);
                    $tax = $subtotal * ($taxRate / 100);
                    $discount = floatval($pendingSale['discount'] ?? 0);
                    $total = $subtotal + $tax - $discount;
                    
                    $newSale = [
                        'id' => $pendingSale['id'] ?? generateId(),
                        'items' => $processedItems,
                        'subtotal' => round($subtotal, 2),
                        'tax' => round($tax, 2),
                        'tax_rate' => $taxRate,
                        'discount' => round($discount, 2),
                        'total' => round($total, 2),
                        'total_cost' => round($totalCost, 2),
                        'profit' => round($total - $totalCost, 2),
                        'payment_method' => $pendingSale['payment_method'] ?? 'cash',
                        'payment_amount' => floatval($pendingSale['payment_amount'] ?? $total),
                        'change' => round(floatval($pendingSale['payment_amount'] ?? $total) - $total, 2),
                        'customer_name' => $pendingSale['customer_name'] ?? '',
                        'customer_phone' => $pendingSale['customer_phone'] ?? '',
                        'notes' => $pendingSale['notes'] ?? '',
                        'date' => $pendingSale['date'] ?? date('Y-m-d H:i:s'),
                        'synced' => true,
                        'offline_created' => true
                    ];
                    
                    $sales[] = $newSale;
                    $response['synced'][] = ['type' => 'sale', 'id' => $newSale['id']];
                    
                } catch (Exception $e) {
                    $response['errors'][] = ['type' => 'sale', 'error' => $e->getMessage()];
                }
            }
            
            writeJson(SALES_FILE, $sales);
            writeJson(PRODUCTS_FILE, $products);
        }
        
        // Sync pending products
        if (isset($input['pending_products']) && is_array($input['pending_products'])) {
            $products = readJson(PRODUCTS_FILE);
            
            foreach ($input['pending_products'] as $pendingProduct) {
                try {
                    $newProduct = [
                        'id' => $pendingProduct['id'] ?? generateId(),
                        'name' => $pendingProduct['name'] ?? '',
                        'sku' => $pendingProduct['sku'] ?? '',
                        'barcode' => $pendingProduct['barcode'] ?? '',
                        'price' => floatval($pendingProduct['price'] ?? 0),
                        'cost' => floatval($pendingProduct['cost'] ?? 0),
                        'stock' => intval($pendingProduct['stock'] ?? 0),
                        'category' => $pendingProduct['category'] ?? 'General',
                        'image' => $pendingProduct['image'] ?? '',
                        'description' => $pendingProduct['description'] ?? '',
                        'created_at' => $pendingProduct['created_at'] ?? date('Y-m-d H:i:s'),
                        'updated_at' => date('Y-m-d H:i:s'),
                        'offline_created' => true
                    ];
                    
                    $products[] = $newProduct;
                    $response['synced'][] = ['type' => 'product', 'id' => $newProduct['id']];
                    
                } catch (Exception $e) {
                    $response['errors'][] = ['type' => 'product', 'error' => $e->getMessage()];
                }
            }
            
            writeJson(PRODUCTS_FILE, $products);
        }
        
        $response['sync_time'] = date('Y-m-d H:i:s');
        echo json_encode($response);
        break;

    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}
?>
