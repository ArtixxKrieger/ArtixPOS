/**
 * POS PRO v3 - Complete Multi-Tenant POS System
 * Features: Auth, Multi-tenancy, Sizes, Modifiers, Analytics, PWA, Offline
 */

// ============================================
// CONFIGURATION
// ============================================
const CONFIG = {
    API_BASE: 'api/',
    DEBOUNCE_DELAY: 300,
    TOKEN_KEY: 'pos_token',
    USER_KEY: 'pos_user',
    SETTINGS_KEY: 'pos_settings',
    OFFLINE_QUEUE_KEY: 'pos_offline_queue'
};

// ============================================
// STATE MANAGEMENT
// ============================================
const state = {
    user: null,
    token: null,
    settings: {
        store_name: 'My Store',
        currency: '₱',
        tax_rate: 0
    },
    products: [],
    pendingOrders: [],
    sales: [],
    clients: [],
    cart: [],
    cartDiscount: 0,
    currentPage: 'dashboard',
    selectedDate: new Date().toISOString().split('T')[0],
    calendarMonth: new Date(),
    isOnline: navigator.onLine,
    deferredPrompt: null,
    charts: {}
};

// ============================================
// UTILITY FUNCTIONS
// ============================================
const utils = {
    generateId: () => {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    },

    formatCurrency: (amount) => {
        const currency = state.settings?.currency || '₱';
        return currency + parseFloat(amount || 0).toFixed(2);
    },

    formatTime: (dateString) => {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    },

    formatDate: (dateString) => {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    },

    formatDateShort: (dateString) => {
        if (!dateString) return 'Today';
        const date = new Date(dateString);
        const today = new Date();
        if (date.toDateString() === today.toDateString()) return 'Today';
        return date.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' });
    },

    debounce: (func, wait) => {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    _activeToasts: new Set(),
    
    showToast: (message, type = 'info', duration = 3000) => {
        // Prevent duplicate toasts with same message within 500ms
        const toastKey = `${message}-${type}`;
        if (utils._activeToasts.has(toastKey)) {
            return;
        }
        utils._activeToasts.add(toastKey);
        setTimeout(() => utils._activeToasts.delete(toastKey), 500);
        
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icons = {
            success: '<polyline points="20 6 9 17 4 12"></polyline>',
            error: '<circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>',
            warning: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line>',
            info: '<circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line>'
        };
        
        toast.innerHTML = `
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                ${icons[type] || icons.info}
            </svg>
            <span>${message}</span>
        `;
        container.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('hiding');
            setTimeout(() => toast.remove(), 200);
        }, duration);
    },

    showLoading: (show = true) => {
        const overlay = document.getElementById('loadingOverlay');
        overlay.classList.toggle('active', show);
    },

    openModal: (modalId) => {
        document.getElementById(modalId).classList.add('active');
        document.body.style.overflow = 'hidden';
    },

    closeModal: (modalId) => {
        document.getElementById(modalId).classList.remove('active');
        document.body.style.overflow = '';
    },

    confirm: (title, message, onConfirm) => {
        document.getElementById('confirmTitle').textContent = title;
        document.getElementById('confirmMessage').textContent = message;
        
        const confirmBtn = document.getElementById('confirmAction');
        const cancelBtn = document.getElementById('cancelConfirm');
        const closeBtn = document.getElementById('closeConfirmModal');
        
        const cleanup = () => {
            utils.closeModal('confirmModal');
            confirmBtn.onclick = null;
            cancelBtn.onclick = null;
            closeBtn.onclick = null;
        };
        
        confirmBtn.onclick = () => {
            cleanup();
            onConfirm();
        };
        
        cancelBtn.onclick = cleanup;
        closeBtn.onclick = cleanup;
        
        utils.openModal('confirmModal');
    },

    saveToStorage: (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.error('Storage error:', e);
        }
    },

    getFromStorage: (key) => {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (e) {
            return null;
        }
    },

    removeFromStorage: (key) => {
        try {
            localStorage.removeItem(key);
        } catch (e) {}
    }
};

// ============================================
// API FUNCTIONS
// ============================================
const api = {
    fetch: async (endpoint, options = {}) => {
        const url = CONFIG.API_BASE + endpoint;
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': state.token ? `Bearer ${state.token}` : ''
            }
        };

        try {
            const response = await fetch(url, { ...defaultOptions, ...options });
            const data = await response.json();
            return { success: response.ok, data, status: response.status };
        } catch (error) {
            console.error('API Error:', error);
            return { success: false, error: error.message, offline: true };
        }
    },

    auth: {
        login: (email, password, remember) => api.fetch('auth.php', {
            method: 'POST',
            body: JSON.stringify({ action: 'login', email, password, remember })
        }),
        logout: (token) => api.fetch('auth.php', {
            method: 'POST',
            body: JSON.stringify({ action: 'logout', token })
        }),
        verify: () => api.fetch('auth.php', {
            method: 'POST',
            body: JSON.stringify({ action: 'verify' })
        }),
        register: (data) => api.fetch('auth.php', {
            method: 'POST',
            body: JSON.stringify({ action: 'register', ...data })
        })
    },

    products: {
        getAll: () => api.fetch('products.php'),
        create: (product) => api.fetch('products.php', {
            method: 'POST',
            body: JSON.stringify(product)
        }),
        update: (id, product) => api.fetch(`products.php?id=${id}`, {
            method: 'PUT',
            body: JSON.stringify({ ...product, id })
        }),
        delete: (id) => api.fetch(`products.php?id=${id}`, { method: 'DELETE' })
    },

    pending: {
        getAll: () => api.fetch('pending.php'),
        create: (order) => api.fetch('pending.php', {
            method: 'POST',
            body: JSON.stringify(order)
        }),
        update: (id, data) => api.fetch(`pending.php?id=${id}`, {
            method: 'PUT',
            body: JSON.stringify({ ...data, id })
        }),
        delete: (id) => api.fetch(`pending.php?id=${id}`, { method: 'DELETE' })
    },

    sales: {
        getAll: () => api.fetch('sales.php'),
        getByDate: (date) => api.fetch(`sales.php?date=${date}`),
        getAnalytics: (start, end) => api.fetch(`sales.php?analytics=1&start=${start}&end=${end}`),
        create: (pendingId) => api.fetch('sales.php', {
            method: 'POST',
            body: JSON.stringify({ pending_id: pendingId })
        }),
        delete: (id) => api.fetch(`sales.php?id=${id}`, { method: 'DELETE' })
    },

    settings: {
        get: () => api.fetch('settings.php'),
        update: (settings) => api.fetch('settings.php', {
            method: 'PUT',
            body: JSON.stringify(settings)
        })
    },

    admin: {
        getClients: () => api.fetch('admin.php'),
        updateClient: (id, data) => api.fetch(`admin.php?id=${id}`, {
            method: 'PUT',
            body: JSON.stringify({ ...data, id })
        }),
        deleteClient: (id) => api.fetch(`admin.php?id=${id}`, { method: 'DELETE' })
    }
};

// ============================================
// AUTHENTICATION
// ============================================
const auth = {
    init: async () => {
        // DEBUG MODE: Check for bypass parameter
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('bypass') === 'admin') {
            console.log('[DEBUG] Login bypass activated');
            // Create fake admin session for testing
            state.token = 'debug-token-' + Date.now();
            state.user = {
                id: 'debug-admin',
                email: 'admin@pos.local',
                name: 'Debug Admin',
                store_name: 'Debug Store',
                role: 'admin'
            };
            state.settings = {
                store_name: 'Debug Store',
                currency: '₱',
                tax_rate: 0
            };
            utils.saveToStorage(CONFIG.TOKEN_KEY, state.token);
            utils.saveToStorage(CONFIG.USER_KEY, state.user);
            utils.saveToStorage(CONFIG.SETTINGS_KEY, state.settings);
            auth.showApp();
            utils.showToast('DEBUG: Logged in as Admin', 'warning');
            return;
        }
        
        // Check for saved token
        const token = utils.getFromStorage(CONFIG.TOKEN_KEY);
        const savedUser = utils.getFromStorage(CONFIG.USER_KEY);
        const savedSettings = utils.getFromStorage(CONFIG.SETTINGS_KEY);
        
        if (token && savedUser) {
            state.token = token;
            state.user = savedUser;
            state.settings = savedSettings || state.settings;
            
            // Verify token with server
            const result = await api.auth.verify();
            if (result.success) {
                state.user = result.data.data.user;
                state.settings = { ...state.settings, ...result.data.data.settings };
                utils.saveToStorage(CONFIG.USER_KEY, state.user);
                utils.saveToStorage(CONFIG.SETTINGS_KEY, state.settings);
                auth.showApp();
            } else {
                auth.logout();
            }
        }
        
        // Setup login form
        document.getElementById('loginForm').addEventListener('submit', auth.handleLogin);
        document.getElementById('logoutBtn').addEventListener('click', auth.logout);
    },

    handleLogin: async (e) => {
        e.preventDefault();
        utils.showLoading(true);
        
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        const remember = document.getElementById('loginRemember').checked;
        
        console.log('[Login] Attempting login for:', email);
        
        try {
            const result = await api.auth.login(email, password, remember);
            console.log('[Login] Result:', result);
            
            if (result.success) {
                state.token = result.data.data.token;
                state.user = result.data.data.user;
                state.settings = { ...state.settings, ...result.data.data.settings };
                
                utils.saveToStorage(CONFIG.TOKEN_KEY, state.token);
                utils.saveToStorage(CONFIG.USER_KEY, state.user);
                utils.saveToStorage(CONFIG.SETTINGS_KEY, state.settings);
                
                utils.showToast('Login successful', 'success');
                auth.showApp();
            } else {
                console.error('[Login] Failed:', result.data?.message || result.error);
                utils.showToast(result.data?.message || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('[Login] Error:', error);
            utils.showToast('Network error. Please try again.', 'error');
        }
        
        utils.showLoading(false);
    },

    logout: () => {
        if (state.token) {
            api.auth.logout(state.token);
        }
        
        state.token = null;
        state.user = null;
        
        utils.removeFromStorage(CONFIG.TOKEN_KEY);
        utils.removeFromStorage(CONFIG.USER_KEY);
        utils.removeFromStorage(CONFIG.SETTINGS_KEY);
        
        auth.showLogin();
        utils.showToast('Logged out', 'info');
    },

    showApp: () => {
        document.getElementById('loginScreen').classList.add('hidden');
        document.getElementById('mainApp').classList.remove('hidden');
        
        // Update UI with user info
        ui.updateHeaderTitles();
        ui.updateDrawerInfo();
        
        // Show admin menu if admin
        if (state.user?.role === 'admin') {
            document.querySelectorAll('.admin-only').forEach(el => el.classList.remove('hidden'));
        }
        
        // Load initial data
        dashboard.init();
        pending.load();
    },

    showLogin: () => {
        document.getElementById('loginScreen').classList.remove('hidden');
        document.getElementById('mainApp').classList.add('hidden');
    }
};

// ============================================
// DASHBOARD
// ============================================
const dashboard = {
    init: async () => {
        await dashboard.loadTodaySales();
        await dashboard.loadSalesForDate(state.selectedDate);
        calendar.render();
    },

    loadTodaySales: async () => {
        const today = new Date().toISOString().split('T')[0];
        const result = await api.sales.getByDate(today);
        
        if (result.success) {
            const sales = result.data.data || [];
            const total = sales.reduce((sum, sale) => sum + (sale.total || 0), 0);
            document.getElementById('todaySales').textContent = utils.formatCurrency(total);
        }
    },

    loadSalesForDate: async (date) => {
        const result = await api.sales.getByDate(date);
        const salesTableBody = document.getElementById('salesTableBody');
        const emptyState = document.getElementById('emptySalesState');
        const salesTable = document.getElementById('salesTable');
        
        if (result.success) {
            const sales = result.data.data || [];
            const total = sales.reduce((sum, sale) => sum + (sale.total || 0), 0);
            
            document.getElementById('selectedDateTotal').textContent = `Total: ${utils.formatCurrency(total)}`;
            
            if (sales.length === 0) {
                salesTable.style.display = 'none';
                emptyState.style.display = 'block';
            } else {
                salesTable.style.display = 'table';
                emptyState.style.display = 'none';
                
                salesTableBody.innerHTML = sales.map(sale => {
                    const items = sale.items || [];
                    const productsText = items.map(i => {
                        let text = i.name;
                        if (i.size_name) text += ` - ${i.size_name}`;
                        if (i.modifiers && i.modifiers.length > 0) {
                            text += ` + ${i.modifiers.map(m => m.name).join(', ')}`;
                        }
                        return `${text} x${i.quantity}`;
                    }).join(', ');
                    
                    return `
                        <tr>
                            <td>${utils.formatTime(sale.created_at)}</td>
                            <td class="products-cell" title="${productsText}">${productsText}</td>
                            <td class="amount-cell">${utils.formatCurrency(sale.total)}</td>
                            <td class="payment-cell">${sale.payment_method}</td>
                            <td class="action-cell">
                                <button class="btn-delete" onclick="dashboard.deleteSale('${sale.id}')">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                    </svg>
                                </button>
                            </td>
                        </tr>
                    `;
                }).join('');
            }
        }
    },

    deleteSale: (id) => {
        utils.confirm('Delete Sale', 'Are you sure you want to delete this sale?', async () => {
            const result = await api.sales.delete(id);
            if (result.success) {
                utils.showToast('Sale deleted', 'success');
                await dashboard.loadSalesForDate(state.selectedDate);
                await dashboard.loadTodaySales();
            } else {
                utils.showToast('Failed to delete sale', 'error');
            }
        });
    }
};

// ============================================
// CALENDAR
// ============================================
const calendar = {
    render: () => {
        const year = state.calendarMonth.getFullYear();
        const month = state.calendarMonth.getMonth();
        
        document.getElementById('calendarMonth').textContent = 
            new Date(year, month).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const daysInPrevMonth = new Date(year, month, 0).getDate();
        
        const grid = document.getElementById('calendarGrid');
        grid.innerHTML = '';
        
        // Previous month days
        for (let i = firstDay - 1; i >= 0; i--) {
            const day = daysInPrevMonth - i;
            const btn = calendar.createDayButton(day, true);
            grid.appendChild(btn);
        }
        
        // Current month days
        for (let day = 1; day <= daysInMonth; day++) {
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const btn = calendar.createDayButton(day, false, dateStr);
            grid.appendChild(btn);
        }
        
        // Next month days
        const remainingCells = 42 - (firstDay + daysInMonth);
        for (let day = 1; day <= remainingCells; day++) {
            const btn = calendar.createDayButton(day, true);
            grid.appendChild(btn);
        }
    },

    createDayButton: (day, isOtherMonth, dateStr) => {
        const btn = document.createElement('button');
        btn.className = 'calendar-day';
        btn.textContent = day;
        
        if (isOtherMonth) btn.classList.add('other-month');
        
        if (dateStr) {
            const today = new Date().toISOString().split('T')[0];
            if (dateStr === today) btn.classList.add('today');
            if (dateStr === state.selectedDate) btn.classList.add('selected');
            
            btn.onclick = () => {
                state.selectedDate = dateStr;
                document.getElementById('selectedDateDisplay').textContent = utils.formatDateShort(dateStr);
                calendar.render();
            };
        }
        
        return btn;
    },

    prevMonth: () => {
        state.calendarMonth.setMonth(state.calendarMonth.getMonth() - 1);
        calendar.render();
    },

    nextMonth: () => {
        state.calendarMonth.setMonth(state.calendarMonth.getMonth() + 1);
        calendar.render();
    },

    toggle: () => {
        const popup = document.getElementById('calendarPopup');
        popup.classList.toggle('hidden');
    }
};

// ============================================
// POS & CART
// ============================================
const pos = {
    init: () => {
        ui.renderProductsGrid();
        ui.renderCart();
    },

    selectProduct: (product) => {
        // If product has sizes or modifiers, show options modal
        if (product.has_sizes == 1 || product.has_modifiers == 1) {
            productOptions.show(product);
        } else {
            // Add directly to cart
            cart.add({
                product_id: product.id,
                name: product.name,
                price: product.price,
                quantity: 1
            });
        }
    },

    finalizeOrder: () => {
        const totals = cart.getTotals();
        document.getElementById('finalizeTotal').textContent = utils.formatCurrency(totals.total);
        document.getElementById('cashAmount').value = '';
        document.getElementById('finalizeChangeDisplay').classList.remove('has-change');
        document.getElementById('finalizeChangeDisplay').querySelector('span').textContent = utils.formatCurrency(0);
        document.getElementById('finalizeCustomerName').value = '';
        document.getElementById('finalizeNotes').value = '';
        
        // Reset to cash
        document.querySelector('input[name="paymentMethod"][value="cash"]').checked = true;
        document.getElementById('cashAmountGroup').style.display = 'block';
        
        utils.openModal('finalizeModal');
    }
};

// ============================================
// PRODUCT OPTIONS (Sizes & Modifiers)
// ============================================
const productOptions = {
    currentProduct: null,
    selectedSize: null,
    selectedModifiers: [],

    show: (product) => {
        productOptions.currentProduct = product;
        productOptions.selectedSize = null;
        productOptions.selectedModifiers = [];
        
        document.getElementById('productOptionsTitle').textContent = product.name;
        
        // Render sizes
        const sizesSection = document.getElementById('sizesSection');
        const sizesList = document.getElementById('sizesList');
        
        if (product.sizes && product.sizes.length > 0) {
            sizesSection.classList.remove('hidden');
            sizesList.innerHTML = product.sizes.map((size, index) => `
                <div class="option-item ${index === 0 ? 'selected' : ''}" data-size-id="${size.id}" onclick="productOptions.selectSize('${size.id}')">
                    <label>
                        <input type="radio" name="size" value="${size.id}" ${index === 0 ? 'checked' : ''}>
                        <span class="option-name">${size.name}</span>
                    </label>
                    <span class="option-price">${utils.formatCurrency(size.price)}</span>
                </div>
            `).join('');
            
            // Select first size by default
            productOptions.selectedSize = product.sizes[0];
        } else {
            sizesSection.classList.add('hidden');
        }
        
        // Render modifiers
        const modifiersSection = document.getElementById('modifiersSection');
        const modifiersList = document.getElementById('modifiersList');
        
        if (product.modifiers && product.modifiers.length > 0) {
            modifiersSection.classList.remove('hidden');
            modifiersList.innerHTML = product.modifiers.map(modifier => `
                <div class="option-item" data-modifier-id="${modifier.id}" onclick="productOptions.toggleModifier('${modifier.id}')">
                    <label>
                        <input type="checkbox" value="${modifier.id}">
                        <span class="option-name">${modifier.name}</span>
                    </label>
                    <span class="option-price">+${utils.formatCurrency(modifier.price)}</span>
                </div>
            `).join('');
        } else {
            modifiersSection.classList.add('hidden');
        }
        
        productOptions.updateTotal();
        utils.openModal('productOptionsModal');
    },

    selectSize: (sizeId) => {
        const product = productOptions.currentProduct;
        productOptions.selectedSize = product.sizes.find(s => s.id === sizeId);
        
        // Update UI
        document.querySelectorAll('#sizesList .option-item').forEach(el => {
            el.classList.toggle('selected', el.dataset.sizeId === sizeId);
            el.querySelector('input').checked = el.dataset.sizeId === sizeId;
        });
        
        productOptions.updateTotal();
    },

    toggleModifier: (modifierId) => {
        const product = productOptions.currentProduct;
        const modifier = product.modifiers.find(m => m.id === modifierId);
        
        const index = productOptions.selectedModifiers.findIndex(m => m.id === modifierId);
        if (index >= 0) {
            productOptions.selectedModifiers.splice(index, 1);
        } else {
            productOptions.selectedModifiers.push(modifier);
        }
        
        // Update UI
        const el = document.querySelector(`#modifiersList .option-item[data-modifier-id="${modifierId}"]`);
        el.classList.toggle('selected');
        el.querySelector('input').checked = index < 0;
        
        productOptions.updateTotal();
    },

    updateTotal: () => {
        let total = 0;
        
        if (productOptions.selectedSize) {
            total += parseFloat(productOptions.selectedSize.price);
        } else if (productOptions.currentProduct) {
            total += parseFloat(productOptions.currentProduct.price);
        }
        
        productOptions.selectedModifiers.forEach(m => {
            total += parseFloat(m.price);
        });
        
        document.getElementById('optionsTotal').textContent = utils.formatCurrency(total);
    },

    addToCart: () => {
        const product = productOptions.currentProduct;
        const size = productOptions.selectedSize;
        const modifiers = productOptions.selectedModifiers;
        
        const cartItem = {
            product_id: product.id,
            name: product.name,
            price: size ? parseFloat(size.price) : parseFloat(product.price),
            quantity: 1
        };
        
        if (size) {
            cartItem.size_id = size.id;
            cartItem.size_name = size.name;
        }
        
        if (modifiers.length > 0) {
            cartItem.modifiers = modifiers.map(m => ({
                id: m.id,
                name: m.name,
                price: parseFloat(m.price)
            }));
        }
        
        cart.add(cartItem);
        utils.closeModal('productOptionsModal');
    }
};

// ============================================
// CART
// ============================================
const cart = {
    add: (item) => {
        // Check if same item already in cart
        const existingIndex = state.cart.findIndex(i => 
            i.product_id === item.product_id && 
            i.size_id === item.size_id &&
            JSON.stringify(i.modifiers?.map(m => m.id).sort()) === 
            JSON.stringify(item.modifiers?.map(m => m.id).sort())
        );

        if (existingIndex >= 0) {
            state.cart[existingIndex].quantity++;
        } else {
            state.cart.push(item);
        }

        ui.renderCart();
        utils.showToast('Added to cart', 'success');
    },

    updateQty: (index, delta) => {
        const item = state.cart[index];
        if (!item) return;

        const newQty = item.quantity + delta;

        if (newQty <= 0) {
            cart.remove(index);
            return;
        }

        item.quantity = newQty;
        ui.renderCart();
    },

    remove: (index) => {
        state.cart.splice(index, 1);
        ui.renderCart();
    },

    clear: () => {
        state.cart = [];
        state.cartDiscount = 0;
        ui.renderCart();
    },

    getTotals: () => {
        let subtotal = 0;
        
        state.cart.forEach(item => {
            let itemTotal = item.price * item.quantity;
            
            // Add modifier prices
            if (item.modifiers) {
                item.modifiers.forEach(m => {
                    itemTotal += m.price * item.quantity;
                });
            }
            
            subtotal += itemTotal;
        });
        
        const discount = state.cartDiscount || 0;
        const taxRate = parseFloat(state.settings?.tax_rate || 0);
        const tax = (subtotal - discount) * (taxRate / 100);
        const total = subtotal + tax - discount;

        return { subtotal, discount, tax, total };
    }
};

// ============================================
// PENDING ORDERS
// ============================================
const pending = {
    load: async () => {
        const result = await api.pending.getAll();
        
        if (result.success) {
            state.pendingOrders = result.data.data || [];
            ui.renderPendingList();
            ui.updatePendingBadge();
        }
    },

    create: async (formData) => {
        const totals = cart.getTotals();
        const paymentMethod = formData.get('paymentMethod');
        const cashAmount = parseFloat(formData.get('cashAmount') || 0);
        
        let paymentAmount = cashAmount;
        let changeAmount = 0;
        
        // For GCash and Maya, payment is exact amount
        if (paymentMethod === 'gcash' || paymentMethod === 'maya') {
            paymentAmount = totals.total;
            changeAmount = 0;
        } else {
            changeAmount = cashAmount - totals.total;
        }

        const orderData = {
            items: state.cart,
            subtotal: totals.subtotal,
            tax: totals.tax,
            discount: totals.discount,
            total: totals.total,
            payment_method: paymentMethod,
            payment_amount: paymentAmount,
            change_amount: changeAmount,
            customer_name: formData.get('customerName') || '',
            notes: formData.get('notes') || ''
        };

        const result = await api.pending.create(orderData);
        
        if (result.success) {
            utils.showToast('Order added to pending', 'success');
            cart.clear();
            utils.closeModal('finalizeModal');
            await pending.load();
            navigation.navigateTo('pending');
        } else {
            utils.showToast(result.data?.message || 'Failed to create pending order', 'error');
        }
    },

    markPaid: async (orderId, amount) => {
        const result = await api.pending.update(orderId, { payment_amount: amount });
        
        if (result.success) {
            const change = result.data.data.change;
            utils.showToast(`Order marked as paid. Change: ${utils.formatCurrency(change)}`, 'success');
            utils.closeModal('markPaidModal');
            await pending.load();
        } else {
            utils.showToast(result.data?.message || 'Failed to mark as paid', 'error');
        }
    },

    complete: async (orderId) => {
        const result = await api.sales.create(orderId);
        
        if (result.success) {
            utils.showToast('Order completed!', 'success');
            await pending.load();
            await dashboard.loadTodaySales();
        } else {
            utils.showToast(result.data?.message || 'Failed to complete order', 'error');
        }
    },

    cancel: (orderId) => {
        utils.confirm('Cancel Order', 'Are you sure you want to cancel this order?', async () => {
            const result = await api.pending.delete(orderId);
            if (result.success) {
                utils.showToast('Order cancelled', 'success');
                await pending.load();
            } else {
                utils.showToast('Failed to cancel order', 'error');
            }
        });
    },

    openMarkPaidModal: (orderId, total) => {
        document.getElementById('markPaidOrderId').value = orderId;
        document.getElementById('markPaidTotal').textContent = utils.formatCurrency(total);
        document.getElementById('markPaidAmount').value = '';
        document.getElementById('markPaidChangeDisplay').classList.remove('has-change');
        document.getElementById('markPaidChangeDisplay').querySelector('span').textContent = utils.formatCurrency(0);
        utils.openModal('markPaidModal');
    }
};

// ============================================
// PRODUCTS
// ============================================
const products = {
    load: async () => {
        const result = await api.products.getAll();
        
        if (result.success) {
            state.products = result.data.data || [];
            ui.renderProductsList();
            ui.updateCategories();
        }
    },

    openAddModal: () => {
        document.getElementById('productModalTitle').textContent = 'Add Product';
        document.getElementById('productForm').reset();
        document.getElementById('productId').value = '';
        
        // Add 3 default size fields (mandatory)
        const sizesContainer = document.getElementById('sizesContainer');
        sizesContainer.innerHTML = '';
        products.addSizeInput('Small', '');
        products.addSizeInput('Medium', '');
        products.addSizeInput('Large', '');
        
        // Clear modifiers (optional)
        document.getElementById('modifiersContainer').innerHTML = '';
        
        utils.openModal('productModal');
    },

    edit: (id) => {
        const product = state.products.find(p => p.id === id);
        if (!product) return;

        document.getElementById('productModalTitle').textContent = 'Edit Product';
        document.getElementById('productId').value = product.id;
        document.getElementById('productName').value = product.name;
        document.getElementById('productPrice').value = product.price;
        document.getElementById('productCategory').value = product.category || '';
        
        // Render sizes - ensure at least 3 size fields
        const sizesContainer = document.getElementById('sizesContainer');
        sizesContainer.innerHTML = '';
        if (product.sizes && product.sizes.length > 0) {
            product.sizes.forEach(size => {
                products.addSizeInput(size.name, size.price);
            });
        }
        // Always ensure at least 3 size rows
        const currentSizeCount = sizesContainer.querySelectorAll('.option-input-row').length;
        for (let i = currentSizeCount; i < 3; i++) {
            products.addSizeInput('', '');
        }
        
        // Render modifiers (optional)
        const modifiersContainer = document.getElementById('modifiersContainer');
        modifiersContainer.innerHTML = '';
        if (product.modifiers && product.modifiers.length > 0) {
            product.modifiers.forEach(modifier => {
                products.addModifierInput(modifier.name, modifier.price);
            });
        }

        utils.openModal('productModal');
    },

    addSizeInput: (name = '', price = '') => {
        const container = document.getElementById('sizesContainer');
        const id = utils.generateId();
        
        const div = document.createElement('div');
        div.className = 'option-input-row';
        div.innerHTML = `
            <input type="text" placeholder="Size name (e.g., Small)" value="${name}" class="size-name" data-id="${id}">
            <input type="number" placeholder="Price" value="${price}" min="0" step="0.01" class="size-price" data-id="${id}">
            <button type="button" class="btn-remove-option" onclick="this.parentElement.remove()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        `;
        container.appendChild(div);
    },

    addModifierInput: (name = '', price = '') => {
        const container = document.getElementById('modifiersContainer');
        const id = utils.generateId();
        
        const div = document.createElement('div');
        div.className = 'option-input-row';
        div.innerHTML = `
            <input type="text" placeholder="Modifier name (e.g., Extra Shot)" value="${name}" class="modifier-name" data-id="${id}">
            <input type="number" placeholder="Price" value="${price}" min="0" step="0.01" class="modifier-price" data-id="${id}">
            <button type="button" class="btn-remove-option" onclick="this.parentElement.remove()">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        `;
        container.appendChild(div);
    },

    save: async (formData) => {
        const id = formData.get('id');
        
        // Collect sizes - at least one size with name AND price is mandatory
        const sizes = [];
        document.querySelectorAll('#sizesContainer .option-input-row').forEach(row => {
            const name = row.querySelector('.size-name').value.trim();
            const price = parseFloat(row.querySelector('.size-price').value);
            if (name && !isNaN(price) && price >= 0) {
                sizes.push({ name, price });
            }
        });
        
        // Validate: at least one size is required
        if (sizes.length === 0) {
            utils.showToast('Please add at least one size with name and price', 'error');
            return false;
        }
        
        // Collect modifiers - truly optional (only include if both name and price provided)
        const modifiers = [];
        document.querySelectorAll('#modifiersContainer .option-input-row').forEach(row => {
            const name = row.querySelector('.modifier-name').value.trim();
            const price = parseFloat(row.querySelector('.modifier-price').value);
            if (name && !isNaN(price) && price >= 0) {
                modifiers.push({ name, price });
            }
        });
        
        const productData = {
            name: formData.get('name').trim(),
            price: parseFloat(formData.get('price')) || 0,
            category: formData.get('category').trim(),
            sizes,
            modifiers
        };

        const result = id
            ? await api.products.update(id, productData)
            : await api.products.create(productData);

        if (result.success) {
            utils.showToast(id ? 'Product updated' : 'Product added', 'success');
            await products.load();
            ui.renderProductsGrid();
            return true;
        } else {
            utils.showToast(result.data?.message || 'Failed to save product', 'error');
            return false;
        }
    },

    delete: (id) => {
        utils.confirm('Delete Product', 'Are you sure you want to delete this product?', async () => {
            const result = await api.products.delete(id);
            if (result.success) {
                utils.showToast('Product deleted', 'success');
                await products.load();
                ui.renderProductsGrid();
            } else {
                utils.showToast(result.data?.message || 'Failed to delete product', 'error');
            }
        });
    }
};

// ============================================
// ANALYTICS
// ============================================
const analytics = {
    init: () => {
        // Set default date range (last 7 days)
        const end = new Date();
        const start = new Date();
        start.setDate(start.getDate() - 6);
        
        document.getElementById('analyticsEndDate').value = end.toISOString().split('T')[0];
        document.getElementById('analyticsStartDate').value = start.toISOString().split('T')[0];
        
        analytics.load();
    },

    load: async () => {
        const start = document.getElementById('analyticsStartDate').value;
        const end = document.getElementById('analyticsEndDate').value;
        
        if (!start || !end) {
            utils.showToast('Please select date range', 'warning');
            return;
        }
        
        utils.showLoading(true);
        
        const result = await api.sales.getAnalytics(start, end);
        
        if (result.success) {
            const data = result.data.data;
            analytics.updateSummaryCards(data);
            analytics.renderCharts(data);
        } else {
            utils.showToast('Failed to load analytics', 'error');
        }
        
        utils.showLoading(false);
    },

    updateSummaryCards: (data) => {
        document.getElementById('analyticsTotalSales').textContent = data.summary.total_sales;
        document.getElementById('analyticsRevenue').textContent = utils.formatCurrency(data.summary.total_revenue);
        document.getElementById('analyticsAvgOrder').textContent = utils.formatCurrency(data.summary.average_order);
        
        const topProducts = Object.entries(data.top_products);
        document.getElementById('analyticsTopProduct').textContent = topProducts.length > 0 ? topProducts[0][0] : '-';
    },

    renderCharts: (data) => {
        // Destroy existing charts properly
        if (state.charts.trend) state.charts.trend.destroy();
        if (state.charts.hours) state.charts.hours.destroy();
        if (state.charts.products) state.charts.products.destroy();
        if (state.charts.payment) state.charts.payment.destroy();
        state.charts = {};
        
        // Sales Trend Chart
        const trendCtx = document.getElementById('salesTrendChart').getContext('2d');
        const trendLabels = Object.keys(data.daily_data);
        const trendValues = Object.values(data.daily_data);
        
        state.charts.trend = new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: trendLabels.map(d => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
                datasets: [{
                    label: 'Sales',
                    data: trendValues,
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, ticks: { callback: v => '₱' + v } }
                }
            }
        });
        
        // Peak Hours Chart
        const hoursCtx = document.getElementById('peakHoursChart').getContext('2d');
        const hourLabels = Array.from({length: 24}, (_, i) => `${i}:00`);
        
        state.charts.hours = new Chart(hoursCtx, {
            type: 'bar',
            data: {
                labels: hourLabels,
                datasets: [{
                    label: 'Sales',
                    data: data.hourly_data,
                    backgroundColor: '#22c55e'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, ticks: { callback: v => '₱' + v } }
                }
            }
        });
        
        // Top Products Chart
        const productsCtx = document.getElementById('topProductsChart').getContext('2d');
        const topProducts = Object.entries(data.top_products).slice(0, 5);
        
        state.charts.products = new Chart(productsCtx, {
            type: 'bar',
            data: {
                labels: topProducts.map(([name]) => name),
                datasets: [{
                    label: 'Revenue',
                    data: topProducts.map(([, d]) => d.revenue),
                    backgroundColor: '#f59e0b'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, ticks: { callback: v => '₱' + v } }
                }
            }
        });
        
        // Payment Methods Chart
        const paymentCtx = document.getElementById('paymentMethodsChart').getContext('2d');
        const paymentMethods = Object.entries(data.payment_methods);
        
        state.charts.payment = new Chart(paymentCtx, {
            type: 'doughnut',
            data: {
                labels: paymentMethods.map(([m]) => m.charAt(0).toUpperCase() + m.slice(1)),
                datasets: [{
                    data: paymentMethods.map(([, d]) => d.amount),
                    backgroundColor: ['#6366f1', '#0075FF', '#8B3DFF', '#22c55e']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }
};

// ============================================
// ADMIN / CLIENTS
// ============================================
const admin = {
    load: async () => {
        const result = await api.admin.getClients();
        
        if (result.success) {
            state.clients = result.data.data || [];
            ui.renderClientsList();
        }
    },

    createClient: async (formData) => {
        const data = {
            store_name: formData.get('storeName').trim(),
            name: formData.get('name').trim(),
            email: formData.get('email').trim(),
            password: formData.get('password')
        };

        const result = await api.auth.register(data);

        if (result.success) {
            utils.showToast('Client created successfully', 'success');
            await admin.load();
            return true;
        } else {
            utils.showToast(result.data?.message || 'Failed to create client', 'error');
            return false;
        }
    },

    toggleClient: async (id, isActive) => {
        const result = await api.admin.updateClient(id, { is_active: isActive });
        
        if (result.success) {
            utils.showToast(isActive ? 'Client activated' : 'Client deactivated', 'success');
            await admin.load();
        } else {
            utils.showToast('Failed to update client', 'error');
        }
    },

    deleteClient: (id) => {
        utils.confirm('Delete Client', 'Are you sure you want to delete this client? This cannot be undone.', async () => {
            const result = await api.admin.deleteClient(id);
            if (result.success) {
                utils.showToast('Client deleted', 'success');
                await admin.load();
            } else {
                utils.showToast('Failed to delete client', 'error');
            }
        });
    }
};

// ============================================
// SETTINGS
// ============================================
const settings = {
    load: async () => {
        const result = await api.settings.get();
        
        if (result.success) {
            const settingsData = result.data.data || {};
            state.settings = { ...state.settings, ...settingsData };
            
            document.getElementById('settingStoreName').value = state.user?.store_name || '';
            document.getElementById('settingCurrency').value = settingsData.currency || '₱';
            document.getElementById('settingTaxRate').value = settingsData.tax_rate || 0;
            document.getElementById('settingAddress').value = settingsData.address || '';
            document.getElementById('settingPhone').value = settingsData.phone || '';
            document.getElementById('settingEmail').value = settingsData.email_contact || '';
            document.getElementById('settingReceiptFooter').value = settingsData.receipt_footer || '';
        }
    },

    save: async () => {
        const newSettings = {
            store_name: document.getElementById('settingStoreName').value.trim(),
            currency: document.getElementById('settingCurrency').value.trim(),
            tax_rate: parseFloat(document.getElementById('settingTaxRate').value) || 0,
            address: document.getElementById('settingAddress').value.trim(),
            phone: document.getElementById('settingPhone').value.trim(),
            email_contact: document.getElementById('settingEmail').value.trim(),
            receipt_footer: document.getElementById('settingReceiptFooter').value.trim()
        };

        const result = await api.settings.update(newSettings);
        
        if (result.success) {
            state.settings = { ...state.settings, ...newSettings };
            state.user.store_name = newSettings.store_name;
            
            utils.saveToStorage(CONFIG.USER_KEY, state.user);
            utils.saveToStorage(CONFIG.SETTINGS_KEY, state.settings);
            
            ui.updateHeaderTitles();
            ui.updateDrawerInfo();
            
            utils.showToast('Settings saved', 'success');
        } else {
            utils.showToast('Failed to save settings', 'error');
        }
    }
};

// ============================================
// UI RENDERING
// ============================================
const ui = {
    updateHeaderTitles: () => {
        const storeName = state.user?.store_name || 'My Store';
        
        document.getElementById('dashboardTitle').textContent = `${storeName} Dashboard`;
        document.getElementById('settingsTitle').textContent = `${storeName} Settings`;
        
        // Update page titles based on current page
        const pageTitles = {
            'dashboard': `${storeName} Dashboard`,
            'pos': `${storeName} POS`,
            'pending': `${storeName} Pending`,
            'analytics': `${storeName} Analytics`,
            'products': `${storeName} Products`,
            'settings': `${storeName} Settings`,
            'admin': `${storeName} Admin`
        };
        
        if (pageTitles[state.currentPage]) {
            document.getElementById('headerTitle').textContent = pageTitles[state.currentPage];
        }
    },

    updateDrawerInfo: () => {
        document.getElementById('drawerStoreName').textContent = state.user?.store_name || 'My Store';
        document.querySelector('.drawer-user .user-name').textContent = state.user?.name || '';
        document.querySelector('.drawer-user .user-role').textContent = state.user?.role || '';
    },

    renderProductsGrid: () => {
        const grid = document.getElementById('productsGrid');
        const searchTerm = document.getElementById('productSearch')?.value.toLowerCase() || '';
        const activeCategory = document.querySelector('.category-tabs .tab-btn.active')?.dataset.category || 'all';

        let filtered = state.products;

        if (searchTerm) {
            filtered = filtered.filter(p => p.name.toLowerCase().includes(searchTerm));
        }

        if (activeCategory !== 'all') {
            filtered = filtered.filter(p => p.category === activeCategory);
        }

        if (filtered.length === 0) {
            grid.innerHTML = `<div class="empty-state" style="grid-column: 1/-1;"><p>No products found</p></div>`;
            return;
        }

        grid.innerHTML = filtered.map(product => {
            const hasOptions = product.has_sizes == 1 || product.has_modifiers == 1;
            const optionsText = [];
            if (product.has_sizes == 1) optionsText.push('Sizes');
            if (product.has_modifiers == 1) optionsText.push('Add-ons');
            
            return `
                <div class="product-card" onclick="pos.selectProduct(${JSON.stringify(product).replace(/"/g, '&quot;')})">
                    <div class="product-card-name">${product.name}</div>
                    <div class="product-card-price">${utils.formatCurrency(product.price)}</div>
                    ${hasOptions ? `<div class="product-card-options">${optionsText.join(' + ')}</div>` : ''}
                </div>
            `;
        }).join('');
    },

    updateCategories: () => {
        const categories = new Set(['All']);
        state.products.forEach(p => {
            if (p.category) categories.add(p.category);
        });

        const tabsContainer = document.getElementById('categoryTabs');
        tabsContainer.innerHTML = Array.from(categories).map(cat => `
            <button class="tab-btn ${cat === 'All' ? 'active' : ''}" data-category="${cat.toLowerCase()}">
                ${cat}
            </button>
        `).join('');

        tabsContainer.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                tabsContainer.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                ui.renderProductsGrid();
            });
        });
    },

    renderCart: () => {
        const cartItems = document.getElementById('cartItems');
        const totals = cart.getTotals();

        if (state.cart.length === 0) {
            cartItems.innerHTML = `
                <div class="empty-cart">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                    <p>Cart is empty</p>
                    <span>Add products to get started</span>
                </div>
            `;
            document.getElementById('finalizeOrderBtn').disabled = true;
        } else {
            cartItems.innerHTML = state.cart.map((item, index) => {
                let details = [];
                if (item.size_name) details.push(item.size_name);
                if (item.modifiers && item.modifiers.length > 0) {
                    details.push(item.modifiers.map(m => m.name).join(', '));
                }
                
                let itemTotal = item.price * item.quantity;
                if (item.modifiers) {
                    item.modifiers.forEach(m => {
                        itemTotal += m.price * item.quantity;
                    });
                }
                
                return `
                    <div class="cart-item">
                        <div class="cart-item-info">
                            <div class="cart-item-name">${item.name}</div>
                            ${details.length > 0 ? `<div class="cart-item-details">${details.join(' + ')}</div>` : ''}
                            <div class="cart-item-price">${utils.formatCurrency(item.price)} each</div>
                        </div>
                        <div class="cart-item-qty">
                            <button class="qty-btn" onclick="cart.updateQty(${index}, -1)">-</button>
                            <span>${item.quantity}</span>
                            <button class="qty-btn" onclick="cart.updateQty(${index}, 1)">+</button>
                        </div>
                        <div class="cart-item-total">${utils.formatCurrency(itemTotal)}</div>
                        <div class="cart-item-remove" onclick="cart.remove(${index})">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                        </div>
                    </div>
                `;
            }).join('');
            document.getElementById('finalizeOrderBtn').disabled = false;
        }

        document.getElementById('subtotal').textContent = utils.formatCurrency(totals.subtotal);
        document.getElementById('tax').textContent = utils.formatCurrency(totals.tax);
        document.getElementById('taxRate').textContent = state.settings?.tax_rate || 0;
        document.getElementById('total').textContent = utils.formatCurrency(totals.total);

        const discountRow = document.getElementById('discountRow');
        if (totals.discount > 0) {
            discountRow.style.display = 'flex';
            document.getElementById('discount').textContent = '-' + utils.formatCurrency(totals.discount);
        } else {
            discountRow.style.display = 'none';
        }
    },

    renderProductsList: () => {
        const list = document.getElementById('productsList');
        const searchTerm = document.getElementById('productListSearch')?.value.toLowerCase() || '';

        let filtered = state.products;
        if (searchTerm) {
            filtered = filtered.filter(p => p.name.toLowerCase().includes(searchTerm));
        }

        if (filtered.length === 0) {
            list.innerHTML = `<div class="empty-state"><p>No products found</p></div>`;
            return;
        }

        list.innerHTML = filtered.map(product => {
            const metaParts = [];
            if (product.category) metaParts.push(product.category);
            if (product.sizes?.length) metaParts.push(`${product.sizes.length} sizes`);
            if (product.modifiers?.length) metaParts.push(`${product.modifiers.length} add-ons`);
            
            return `
                <div class="product-list-item">
                    <div class="product-list-info">
                        <div class="product-list-name">${product.name}</div>
                        <div class="product-list-meta">${metaParts.join(' • ')}</div>
                    </div>
                    <div class="product-list-price">${utils.formatCurrency(product.price)}</div>
                    <div class="product-list-actions">
                        <button class="btn-icon" onclick="products.edit('${product.id}')">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                        </button>
                        <button class="btn-icon" onclick="products.delete('${product.id}')">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    },

    renderPendingList: () => {
        const list = document.getElementById('pendingList');
        const emptyState = document.getElementById('emptyPendingState');

        if (state.pendingOrders.length === 0) {
            list.innerHTML = '';
            emptyState.style.display = 'block';
            return;
        }

        emptyState.style.display = 'none';

        list.innerHTML = state.pendingOrders.map(order => {
            const items = order.items || [];
            const itemsHtml = items.map(item => {
                let text = item.name;
                if (item.size_name) text += ` - ${item.size_name}`;
                if (item.modifiers?.length) text += ` + ${item.modifiers.map(m => m.name).join(', ')}`;
                
                let itemTotal = item.price * item.quantity;
                if (item.modifiers) {
                    item.modifiers.forEach(m => itemTotal += m.price * item.quantity);
                }
                
                return `
                    <div class="pending-item">
                        <span>${text} x${item.quantity}</span>
                        <span>${utils.formatCurrency(itemTotal)}</span>
                    </div>
                `;
            }).join('');

            const isPaid = order.status === 'paid';
            const changeText = isPaid && order.change_amount > 0 
                ? `<div class="pending-change">Change: ${utils.formatCurrency(order.change_amount)}</div>` 
                : '';

            return `
                <div class="pending-card ${order.status}">
                    <div class="pending-header">
                        <span class="pending-id">#${order.id.slice(-6).toUpperCase()}</span>
                        <span class="pending-status ${order.status}">${order.status}</span>
                    </div>
                    <div class="pending-items">${itemsHtml}</div>
                    <div class="pending-total">
                        <span>Total</span>
                        <span>${utils.formatCurrency(order.total)}</span>
                    </div>
                    <div class="pending-payment">
                        <span class="pending-payment-method">${order.payment_method}</span>
                        ${order.customer_name ? `<span>| ${order.customer_name}</span>` : ''}
                    </div>
                    ${order.notes ? `<div class="pending-notes">Notes: ${order.notes}</div>` : ''}
                    ${changeText}
                    <div class="pending-actions">
                        <button class="btn-secondary btn-danger" onclick="pending.cancel('${order.id}')">Cancel</button>
                        ${!isPaid ? `<button class="btn-secondary" onclick="pending.openMarkPaidModal('${order.id}', ${order.total})">Mark Paid</button>` : ''}
                        <button class="btn-primary" onclick="pending.complete('${order.id}')">Complete</button>
                    </div>
                </div>
            `;
        }).join('');
    },

    updatePendingBadge: () => {
        const badge = document.getElementById('pendingBadge');
        const count = state.pendingOrders.length;
        badge.textContent = count;
        badge.style.display = count > 0 ? 'inline-block' : 'none';
    },

    renderClientsList: () => {
        const list = document.getElementById('clientsList');
        
        if (state.clients.length === 0) {
            list.innerHTML = `<div class="empty-state"><p>No clients yet</p></div>`;
            return;
        }

        list.innerHTML = state.clients.map(client => `
            <div class="client-card">
                <div class="client-header">
                    <span class="client-store">${client.store_name}</span>
                    <span class="client-status ${client.is_active ? 'active' : 'inactive'}">
                        ${client.is_active ? 'Active' : 'Inactive'}
                    </span>
                </div>
                <div class="client-info">
                    <span><strong>${client.name}</strong></span>
                    <span>${client.email}</span>
                    <span>Created: ${utils.formatDate(client.created_at)}</span>
                </div>
                <div class="client-actions">
                    <button class="btn-secondary" onclick="admin.toggleClient('${client.id}', ${client.is_active ? 0 : 1})">
                        ${client.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button class="btn-danger" onclick="admin.deleteClient('${client.id}')">Delete</button>
                </div>
            </div>
        `).join('');
    }
};

// ============================================
// NAVIGATION
// ============================================
const navigation = {
    init: () => {
        document.getElementById('menuBtn').addEventListener('click', () => {
            document.getElementById('navDrawer').classList.add('open');
            document.getElementById('drawerOverlay').classList.add('open');
        });

        document.getElementById('closeDrawer').addEventListener('click', navigation.closeDrawer);
        document.getElementById('drawerOverlay').addEventListener('click', navigation.closeDrawer);

        document.querySelectorAll('.nav-link, .bottom-nav-item').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = link.dataset.page;
                navigation.navigateTo(page);
                navigation.closeDrawer();
            });
        });
    },

    closeDrawer: () => {
        document.getElementById('navDrawer').classList.remove('open');
        document.getElementById('drawerOverlay').classList.remove('open');
        document.getElementById('calendarPopup').classList.add('hidden');
    },

    navigateTo: (page) => {
        state.currentPage = page;

        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.nav-link, .bottom-nav-item').forEach(l => l.classList.remove('active'));

        document.getElementById(page + 'Page')?.classList.add('active');
        document.querySelectorAll(`[data-page="${page}"]`).forEach(el => el.classList.add('active'));

        // Update header title
        ui.updateHeaderTitles();

        switch (page) {
            case 'dashboard':
                dashboard.init();
                break;
            case 'pos':
                pos.init();
                break;
            case 'pending':
                pending.load();
                break;
            case 'analytics':
                analytics.init();
                break;
            case 'products':
                products.load();
                break;
            case 'settings':
                settings.load();
                break;
            case 'admin':
                admin.load();
                break;
        }
    }
};

// ============================================
// PWA INSTALL
// ============================================
const pwa = {
    init: () => {
        // Listen for beforeinstallprompt
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            state.deferredPrompt = e;
            document.getElementById('installAppBtn').style.display = 'flex';
            document.getElementById('installHint').style.display = 'none';
        });

        // Listen for app installed
        window.addEventListener('appinstalled', () => {
            state.deferredPrompt = null;
            document.getElementById('installAppBtn').style.display = 'none';
            document.getElementById('installHint').textContent = 'App installed successfully!';
            document.getElementById('installHint').style.display = 'block';
            utils.showToast('App installed successfully!', 'success');
        });

        // Install button click
        document.getElementById('installAppBtn').addEventListener('click', async () => {
            if (!state.deferredPrompt) return;
            
            state.deferredPrompt.prompt();
            const { outcome } = await state.deferredPrompt.userChoice;
            
            if (outcome === 'accepted') {
                utils.showToast('Installing app...', 'success');
            }
            
            state.deferredPrompt = null;
        });

        // Register service worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js')
                .then(reg => console.log('[SW] Registered'))
                .catch(err => console.log('[SW] Registration failed:', err));
        }
    }
};

// ============================================
// EVENT LISTENERS
// ============================================
function initEventListeners() {
    // Theme toggle
    document.getElementById('themeBtn').addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('pos_theme', next);
    });

    // Product search
    document.getElementById('productSearch').addEventListener('input',
        utils.debounce(() => ui.renderProductsGrid(), CONFIG.DEBOUNCE_DELAY)
    );

    // Product list search
    document.getElementById('productListSearch').addEventListener('input',
        utils.debounce(() => ui.renderProductsList(), CONFIG.DEBOUNCE_DELAY)
    );

    // Clear cart
    document.getElementById('clearCart').addEventListener('click', () => {
        if (state.cart.length > 0) {
            utils.confirm('Clear Cart', 'Are you sure you want to clear the cart?', () => {
                cart.clear();
            });
        }
    });

    // Add product button
    document.getElementById('addProductBtn').addEventListener('click', products.openAddModal);

    // Product form
    document.getElementById('productForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        if (await products.save(formData)) {
            utils.closeModal('productModal');
        }
    });

    document.getElementById('cancelProduct').addEventListener('click', () => utils.closeModal('productModal'));
    document.getElementById('closeProductModal').addEventListener('click', () => utils.closeModal('productModal'));

    // Add size/modifier buttons
    document.getElementById('addSizeBtn').addEventListener('click', () => products.addSizeInput());
    document.getElementById('addModifierBtn').addEventListener('click', () => products.addModifierInput());

    // Product options modal
    document.getElementById('cancelProductOptions').addEventListener('click', () => utils.closeModal('productOptionsModal'));
    document.getElementById('closeProductOptions').addEventListener('click', () => utils.closeModal('productOptionsModal'));
    document.getElementById('addToCartWithOptions').addEventListener('click', productOptions.addToCart);

    // Finalize order
    document.getElementById('finalizeOrderBtn').addEventListener('click', pos.finalizeOrder);

    // Payment method change
    document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
        radio.addEventListener('change', (e) => {
            const cashGroup = document.getElementById('cashAmountGroup');
            cashGroup.style.display = e.target.value === 'cash' ? 'block' : 'none';
        });
    });

    // Cash amount change
    document.getElementById('cashAmount').addEventListener('input', (e) => {
        const amount = parseFloat(e.target.value) || 0;
        const totals = cart.getTotals();
        const change = amount - totals.total;
        const changeDisplay = document.getElementById('finalizeChangeDisplay');
        changeDisplay.querySelector('span').textContent = utils.formatCurrency(Math.max(0, change));
        changeDisplay.classList.toggle('has-change', change > 0);
    });

    // Finalize form
    document.getElementById('finalizeForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        await pending.create(formData);
    });

    document.getElementById('cancelFinalize').addEventListener('click', () => utils.closeModal('finalizeModal'));
    document.getElementById('closeFinalizeModal').addEventListener('click', () => utils.closeModal('finalizeModal'));

    // Mark paid form
    document.getElementById('markPaidAmount').addEventListener('input', (e) => {
        const amount = parseFloat(e.target.value) || 0;
        const totalText = document.getElementById('markPaidTotal').textContent;
        const total = parseFloat(totalText.replace(/[^0-9.]/g, ''));
        const change = amount - total;
        const changeDisplay = document.getElementById('markPaidChangeDisplay');
        changeDisplay.querySelector('span').textContent = utils.formatCurrency(Math.max(0, change));
        changeDisplay.classList.toggle('has-change', change > 0);
    });

    document.getElementById('markPaidForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const orderId = document.getElementById('markPaidOrderId').value;
        const amount = parseFloat(document.getElementById('markPaidAmount').value) || 0;
        await pending.markPaid(orderId, amount);
    });

    document.getElementById('cancelMarkPaid').addEventListener('click', () => utils.closeModal('markPaidModal'));
    document.getElementById('closeMarkPaidModal').addEventListener('click', () => utils.closeModal('markPaidModal'));

    // Discount
    document.getElementById('addDiscount').addEventListener('click', () => {
        utils.openModal('discountModal');
    });

    document.querySelectorAll('.discount-preset').forEach(btn => {
        btn.addEventListener('click', () => {
            state.cartDiscount = parseFloat(btn.dataset.amount);
            ui.renderCart();
            utils.closeModal('discountModal');
            utils.showToast('Discount applied', 'success');
        });
    });

    document.getElementById('applyDiscount').addEventListener('click', () => {
        const custom = parseFloat(document.getElementById('customDiscount').value) || 0;
        state.cartDiscount = custom;
        ui.renderCart();
        utils.closeModal('discountModal');
        utils.showToast('Discount applied', 'success');
    });

    document.getElementById('removeDiscount').addEventListener('click', () => {
        state.cartDiscount = 0;
        ui.renderCart();
        utils.closeModal('discountModal');
        utils.showToast('Discount removed', 'info');
    });

    document.getElementById('closeDiscountModal').addEventListener('click', () => utils.closeModal('discountModal'));

    // Calendar
    document.getElementById('datePickerBtn').addEventListener('click', calendar.toggle);
    document.getElementById('prevMonth').addEventListener('click', calendar.prevMonth);
    document.getElementById('nextMonth').addEventListener('click', calendar.nextMonth);
    document.getElementById('viewSalesBtn').addEventListener('click', () => {
        dashboard.loadSalesForDate(state.selectedDate);
        document.getElementById('calendarPopup').classList.add('hidden');
    });

    // Settings
    document.getElementById('saveSettings').addEventListener('click', settings.save);

    // Analytics
    document.getElementById('updateAnalyticsBtn').addEventListener('click', analytics.load);

    // Admin
    document.getElementById('addClientBtn').addEventListener('click', () => {
        document.getElementById('clientForm').reset();
        utils.openModal('clientModal');
    });

    document.getElementById('clientForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        if (await admin.createClient(formData)) {
            utils.closeModal('clientModal');
        }
    });

    document.getElementById('cancelClient').addEventListener('click', () => utils.closeModal('clientModal'));
    document.getElementById('closeClientModal').addEventListener('click', () => utils.closeModal('clientModal'));

    // Online/offline detection
    window.addEventListener('online', () => {
        state.isOnline = true;
        utils.showToast('Back online', 'success');
    });

    window.addEventListener('offline', () => {
        state.isOnline = false;
        utils.showToast('You are offline. Changes will sync when connection is restored.', 'warning');
    });

    // DEBUG: Bypass login button
    const bypassBtn = document.getElementById('bypassLoginBtn');
    if (bypassBtn) {
        bypassBtn.addEventListener('click', () => {
            console.log('[DEBUG] Bypass login clicked');
            window.location.href = window.location.pathname + '?bypass=admin';
        });
    }

    // DEBUG: Clear all data button
    const clearDataBtn = document.getElementById('clearDataBtn');
    if (clearDataBtn) {
        clearDataBtn.addEventListener('click', () => {
            if (confirm('WARNING: This will clear ALL local data including login sessions. Continue?')) {
                localStorage.clear();
                utils.showToast('All local data cleared. Reloading...', 'info');
                setTimeout(() => window.location.reload(), 1500);
            }
        });
    }
}

// ============================================
// INITIALIZATION
// ============================================
async function init() {
    // Load theme
    const savedTheme = localStorage.getItem('pos_theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);

    // Initialize auth
    await auth.init();

    // Initialize navigation
    navigation.init();

    // Initialize event listeners
    initEventListeners();

    // Initialize PWA
    pwa.init();

    console.log('POS Pro v3 initialized');
}

// Start the app
document.addEventListener('DOMContentLoaded', init);
