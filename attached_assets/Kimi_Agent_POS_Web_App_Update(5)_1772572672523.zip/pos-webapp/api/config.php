<?php
/**
 * POS System Configuration - SQLite Database with Multi-Tenancy
 * All data stored in data.db with security and auto-creation
 */

// Prevent direct access
if (!defined('POS_ACCESS')) {
    header('HTTP/1.0 403 Forbidden');
    exit('Direct access denied');
}

// CORS headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Database configuration
$DB_PATH = __DIR__ . '/../data/data.db';
$DB_DIR = __DIR__ . '/../data';

// Ensure data directory exists with proper permissions
if (!is_dir($DB_DIR)) {
    @mkdir($DB_DIR, 0750, true);
}

// Session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', 86400 * 30); // 30 days for "Remember Me"

/**
 * Get database connection with auto-creation
 */
function getDB() {
    global $DB_PATH;
    
    $dbExists = file_exists($DB_PATH);
    $db = new SQLite3($DB_PATH);
    $db->busyTimeout(5000);
    
    if (!$dbExists) {
        initializeDatabase($db);
    }
    
    return $db;
}

/**
 * Initialize database with all tables
 */
function initializeDatabase($db) {
    // Enable foreign keys
    $db->exec('PRAGMA foreign_keys = ON');
    
    // Users table (for multi-tenancy)
    $db->exec('CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        name TEXT NOT NULL,
        store_name TEXT DEFAULT "My Store",
        role TEXT DEFAULT "client",
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        last_login TEXT
    )');
    
    // User settings table
    $db->exec('CREATE TABLE IF NOT EXISTS user_settings (
        user_id TEXT PRIMARY KEY,
        currency TEXT DEFAULT "₱",
        tax_rate REAL DEFAULT 0,
        address TEXT,
        phone TEXT,
        email_contact TEXT,
        receipt_footer TEXT DEFAULT "Thank you for your business!",
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )');
    
    // Products table (simplified per user)
    $db->exec('CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        category TEXT DEFAULT "General",
        has_sizes INTEGER DEFAULT 0,
        has_modifiers INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )');
    
    // Product sizes table
    $db->exec('CREATE TABLE IF NOT EXISTS product_sizes (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        size_name TEXT NOT NULL,
        price REAL NOT NULL,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )');
    
    // Product modifiers table
    $db->exec('CREATE TABLE IF NOT EXISTS product_modifiers (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        modifier_name TEXT NOT NULL,
        price REAL NOT NULL,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )');
    
    // Pending orders table
    $db->exec('CREATE TABLE IF NOT EXISTS pending_orders (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        items TEXT NOT NULL,
        subtotal REAL NOT NULL,
        tax REAL DEFAULT 0,
        discount REAL DEFAULT 0,
        total REAL NOT NULL,
        payment_method TEXT DEFAULT "cash",
        payment_amount REAL DEFAULT 0,
        change_amount REAL DEFAULT 0,
        status TEXT DEFAULT "unpaid",
        customer_name TEXT,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )');
    
    // Completed sales table
    $db->exec('CREATE TABLE IF NOT EXISTS sales (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        items TEXT NOT NULL,
        subtotal REAL NOT NULL,
        tax REAL DEFAULT 0,
        discount REAL DEFAULT 0,
        total REAL NOT NULL,
        payment_method TEXT NOT NULL,
        payment_amount REAL NOT NULL,
        change_amount REAL DEFAULT 0,
        customer_name TEXT,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )');
    
    // Sessions table for token-based auth
    $db->exec('CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )');
    
    // Login attempts table for rate limiting
    $db->exec('CREATE TABLE IF NOT EXISTS login_attempts (
        ip TEXT PRIMARY KEY,
        attempts INTEGER DEFAULT 0,
        last_attempt TEXT DEFAULT CURRENT_TIMESTAMP,
        locked_until TEXT
    )');
    
    // Create Super Admin if not exists
    createSuperAdmin($db);
    
    // Create indexes for performance
    $db->exec('CREATE INDEX IF NOT EXISTS idx_products_user ON products(user_id)');
    $db->exec('CREATE INDEX IF NOT EXISTS idx_sales_user ON sales(user_id)');
    $db->exec('CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(created_at)');
    $db->exec('CREATE INDEX IF NOT EXISTS idx_pending_user ON pending_orders(user_id)');
}

/**
 * Create Super Admin account
 */
function createSuperAdmin($db) {
    $adminId = generateId();
    $adminEmail = 'admin@pos.local';
    $adminPassword = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => 12]);
    
    $stmt = $db->prepare('INSERT OR IGNORE INTO users (id, email, password_hash, name, store_name, role) 
                          VALUES (:id, :email, :password, :name, :store, :role)');
    $stmt->bindValue(':id', $adminId);
    $stmt->bindValue(':email', $adminEmail);
    $stmt->bindValue(':password', $adminPassword);
    $stmt->bindValue(':name', 'Super Admin');
    $stmt->bindValue(':store', 'POS System');
    $stmt->bindValue(':role', 'admin');
    $stmt->execute();
    
    // Create default settings for admin
    $stmt = $db->prepare('INSERT OR IGNORE INTO user_settings (user_id) VALUES (:id)');
    $stmt->bindValue(':id', $adminId);
    $stmt->execute();
}

/**
 * Generate unique ID
 */
function generateId() {
    return bin2hex(random_bytes(16));
}

/**
 * Generate secure token
 */
function generateToken() {
    return bin2hex(random_bytes(32));
}

/**
 * Get JSON input
 */
function getInput() {
    $json = file_get_contents('php://input');
    return json_decode($json, true) ?: [];
}

/**
 * Send JSON response
 */
function jsonResponse($success, $data = null, $message = '') {
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'message' => $message
    ]);
    exit;
}

/**
 * Get current user from session/token
 */
function getCurrentUser($db) {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';
    
    if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        $token = $matches[1];
        
        $stmt = $db->prepare('SELECT u.* FROM users u 
                              JOIN sessions s ON u.id = s.user_id 
                              WHERE s.token = :token AND s.expires_at > datetime("now")');
        $stmt->bindValue(':token', $token);
        $result = $stmt->execute();
        $user = $result->fetchArray(SQLITE3_ASSOC);
        
        if ($user) {
            unset($user['password_hash']);
            return $user;
        }
    }
    
    return null;
}

/**
 * Check rate limiting
 */
function checkRateLimit($db, $ip) {
    $stmt = $db->prepare('SELECT * FROM login_attempts WHERE ip = :ip');
    $stmt->bindValue(':ip', $ip);
    $result = $stmt->execute();
    $record = $result->fetchArray(SQLITE3_ASSOC);
    
    if ($record) {
        // Check if locked
        if ($record['locked_until'] && strtotime($record['locked_until']) > time()) {
            $wait = ceil((strtotime($record['locked_until']) - time()) / 60);
            jsonResponse(false, null, "Too many attempts. Try again in {$wait} minutes.");
        }
        
        // Reset if last attempt was more than 1 hour ago
        if (strtotime($record['last_attempt']) < time() - 3600) {
            $stmt = $db->prepare('UPDATE login_attempts SET attempts = 0, locked_until = NULL WHERE ip = :ip');
            $stmt->bindValue(':ip', $ip);
            $stmt->execute();
            return true;
        }
        
        // Block if too many attempts
        if ($record['attempts'] >= 5) {
            $lockedUntil = date('Y-m-d H:i:s', time() + 900); // 15 minutes
            $stmt = $db->prepare('UPDATE login_attempts SET locked_until = :locked WHERE ip = :ip');
            $stmt->bindValue(':locked', $lockedUntil);
            $stmt->bindValue(':ip', $ip);
            $stmt->execute();
            jsonResponse(false, null, 'Too many failed attempts. Account locked for 15 minutes.');
        }
    }
    
    return true;
}

/**
 * Record failed login attempt
 */
function recordFailedLogin($db, $ip) {
    $stmt = $db->prepare('INSERT OR REPLACE INTO login_attempts (ip, attempts, last_attempt) 
                          VALUES (:ip, COALESCE((SELECT attempts FROM login_attempts WHERE ip = :ip), 0) + 1, datetime("now"))');
    $stmt->bindValue(':ip', $ip);
    $stmt->execute();
}

/**
 * Clear login attempts on success
 */
function clearLoginAttempts($db, $ip) {
    $stmt = $db->prepare('DELETE FROM login_attempts WHERE ip = :ip');
    $stmt->bindValue(':ip', $ip);
    $stmt->execute();
}

// Initialize database on first load
try {
    $db = getDB();
    $db->close();
} catch (Exception $e) {
    error_log('Database initialization error: ' . $e->getMessage());
}
?>
