<?php
define('POS_ACCESS', true);
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = getInput();
$db = getDB();

// Verify user is logged in
$currentUser = getCurrentUser($db);
if (!$currentUser) {
    jsonResponse(false, null, 'Unauthorized - Please login');
}

$userId = $currentUser['id'];

switch ($method) {
    case 'GET':
        // Get all pending orders for current user
        $stmt = $db->prepare('SELECT * FROM pending_orders WHERE user_id = :user_id ORDER BY created_at DESC');
        $stmt->bindValue(':user_id', $userId);
        $result = $stmt->execute();
        
        $orders = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $row['items'] = json_decode($row['items'], true);
            $orders[] = $row;
        }
        
        jsonResponse(true, $orders);
        break;

    case 'POST':
        // Create new pending order
        $items = $input['items'] ?? [];
        
        if (empty($items)) {
            jsonResponse(false, null, 'No items in order');
        }
        
        $id = generateId();
        $subtotal = floatval($input['subtotal'] ?? 0);
        $tax = floatval($input['tax'] ?? 0);
        $discount = floatval($input['discount'] ?? 0);
        $total = floatval($input['total'] ?? 0);
        $paymentMethod = $input['payment_method'] ?? 'cash';
        $paymentAmount = floatval($input['payment_amount'] ?? 0);
        $changeAmount = floatval($input['change_amount'] ?? 0);
        
        // GCash and Maya are auto-paid
        $status = ($paymentMethod === 'gcash' || $paymentMethod === 'maya') ? 'paid' : 'unpaid';
        
        $customerName = trim($input['customer_name'] ?? '');
        $notes = trim($input['notes'] ?? '');
        
        $stmt = $db->prepare('INSERT INTO pending_orders (id, user_id, items, subtotal, tax, discount, total, payment_method, payment_amount, change_amount, status, customer_name, notes) 
                              VALUES (:id, :user_id, :items, :subtotal, :tax, :discount, :total, :payment_method, :payment_amount, :change_amount, :status, :customer_name, :notes)');
        
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':user_id', $userId);
        $stmt->bindValue(':items', json_encode($items));
        $stmt->bindValue(':subtotal', $subtotal);
        $stmt->bindValue(':tax', $tax);
        $stmt->bindValue(':discount', $discount);
        $stmt->bindValue(':total', $total);
        $stmt->bindValue(':payment_method', $paymentMethod);
        $stmt->bindValue(':payment_amount', $paymentAmount);
        $stmt->bindValue(':change_amount', $changeAmount);
        $stmt->bindValue(':status', $status);
        $stmt->bindValue(':customer_name', $customerName);
        $stmt->bindValue(':notes', $notes);
        
        if ($stmt->execute()) {
            jsonResponse(true, ['id' => $id, 'status' => $status], 'Order added to pending');
        } else {
            jsonResponse(false, null, 'Failed to create pending order');
        }
        break;

    case 'PUT':
        // Update pending order (mark as paid)
        $id = $input['id'] ?? null;
        
        if (!$id) {
            jsonResponse(false, null, 'Order ID required');
        }
        
        // Verify ownership
        $stmt = $db->prepare('SELECT total FROM pending_orders WHERE id = :id AND user_id = :user_id');
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':user_id', $userId);
        $result = $stmt->execute();
        $order = $result->fetchArray(SQLITE3_ASSOC);
        
        if (!$order) {
            jsonResponse(false, null, 'Order not found');
        }
        
        $paymentAmount = floatval($input['payment_amount'] ?? 0);
        $changeAmount = $paymentAmount - $order['total'];
        
        $stmt = $db->prepare('UPDATE pending_orders SET status = "paid", payment_amount = :payment_amount, change_amount = :change_amount WHERE id = :id AND user_id = :user_id');
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':user_id', $userId);
        $stmt->bindValue(':payment_amount', $paymentAmount);
        $stmt->bindValue(':change_amount', $changeAmount);
        
        if ($stmt->execute()) {
            jsonResponse(true, ['change' => $changeAmount], 'Order marked as paid');
        } else {
            jsonResponse(false, null, 'Failed to update order');
        }
        break;

    case 'DELETE':
        // Delete pending order
        $id = $_GET['id'] ?? $input['id'] ?? null;
        
        if (!$id) {
            jsonResponse(false, null, 'Order ID required');
        }
        
        $stmt = $db->prepare('DELETE FROM pending_orders WHERE id = :id AND user_id = :user_id');
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':user_id', $userId);
        
        if ($stmt->execute() && $db->changes() > 0) {
            jsonResponse(true, null, 'Order cancelled');
        } else {
            jsonResponse(false, null, 'Order not found');
        }
        break;

    default:
        jsonResponse(false, null, 'Method not allowed');
}

$db->close();
?>
