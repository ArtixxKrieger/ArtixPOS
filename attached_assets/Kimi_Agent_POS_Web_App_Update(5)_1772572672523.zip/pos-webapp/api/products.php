<?php
define('POS_ACCESS', true);
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = getInput();
$db = getDB();

// Verify user is logged in
$currentUser = getCurrentUser($db);
if (!$currentUser) {
    jsonResponse(false, null, 'Unauthorized - Please login');
}

$userId = $currentUser['id'];

switch ($method) {
    case 'GET':
        // Get all products for current user with sizes and modifiers
        if (isset($_GET['id'])) {
            $product = getProductWithDetails($db, $_GET['id'], $userId);
            jsonResponse(true, $product);
        } else {
            $products = getAllProductsWithDetails($db, $userId);
            jsonResponse(true, $products);
        }
        break;

    case 'POST':
        // Add new product with sizes and modifiers
        $db->exec('BEGIN TRANSACTION');
        
        try {
            $productId = generateId();
            $name = trim($input['name'] ?? '');
            $price = floatval($input['price'] ?? 0);
            $category = trim($input['category'] ?? 'General');
            $sizes = $input['sizes'] ?? [];
            $modifiers = $input['modifiers'] ?? [];
            
            if (empty($name)) {
                throw new Exception('Product name is required');
            }
            
            $hasSizes = !empty($sizes) ? 1 : 0;
            $hasModifiers = !empty($modifiers) ? 1 : 0;
            
            // Insert product
            $stmt = $db->prepare('INSERT INTO products (id, user_id, name, price, category, has_sizes, has_modifiers) 
                                  VALUES (:id, :user_id, :name, :price, :category, :has_sizes, :has_modifiers)');
            $stmt->bindValue(':id', $productId);
            $stmt->bindValue(':user_id', $userId);
            $stmt->bindValue(':name', $name);
            $stmt->bindValue(':price', $price);
            $stmt->bindValue(':category', $category);
            $stmt->bindValue(':has_sizes', $hasSizes);
            $stmt->bindValue(':has_modifiers', $hasModifiers);
            $stmt->execute();
            
            // Insert sizes
            foreach ($sizes as $size) {
                $sizeId = generateId();
                $stmt = $db->prepare('INSERT INTO product_sizes (id, product_id, size_name, price) 
                                      VALUES (:id, :product_id, :size_name, :price)');
                $stmt->bindValue(':id', $sizeId);
                $stmt->bindValue(':product_id', $productId);
                $stmt->bindValue(':size_name', $size['name']);
                $stmt->bindValue(':price', floatval($size['price']));
                $stmt->execute();
            }
            
            // Insert modifiers
            foreach ($modifiers as $modifier) {
                $modifierId = generateId();
                $stmt = $db->prepare('INSERT INTO product_modifiers (id, product_id, modifier_name, price) 
                                      VALUES (:id, :product_id, :modifier_name, :price)');
                $stmt->bindValue(':id', $modifierId);
                $stmt->bindValue(':product_id', $productId);
                $stmt->bindValue(':modifier_name', $modifier['name']);
                $stmt->bindValue(':price', floatval($modifier['price']));
                $stmt->execute();
            }
            
            $db->exec('COMMIT');
            
            $product = getProductWithDetails($db, $productId, $userId);
            jsonResponse(true, $product, 'Product added successfully');
            
        } catch (Exception $e) {
            $db->exec('ROLLBACK');
            jsonResponse(false, null, $e->getMessage());
        }
        break;

    case 'PUT':
        // Update product with sizes and modifiers
        $id = $input['id'] ?? null;
        
        if (!$id) {
            jsonResponse(false, null, 'Product ID required');
        }
        
        // Verify ownership
        $stmt = $db->prepare('SELECT id FROM products WHERE id = :id AND user_id = :user_id');
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':user_id', $userId);
        $result = $stmt->execute();
        if (!$result->fetchArray()) {
            jsonResponse(false, null, 'Product not found or access denied');
        }
        
        $db->exec('BEGIN TRANSACTION');
        
        try {
            $name = trim($input['name'] ?? '');
            $price = floatval($input['price'] ?? 0);
            $category = trim($input['category'] ?? 'General');
            $sizes = $input['sizes'] ?? [];
            $modifiers = $input['modifiers'] ?? [];
            
            if (empty($name)) {
                throw new Exception('Product name is required');
            }
            
            $hasSizes = !empty($sizes) ? 1 : 0;
            $hasModifiers = !empty($modifiers) ? 1 : 0;
            
            // Update product
            $stmt = $db->prepare('UPDATE products SET name = :name, price = :price, category = :category, 
                                  has_sizes = :has_sizes, has_modifiers = :has_modifiers WHERE id = :id');
            $stmt->bindValue(':id', $id);
            $stmt->bindValue(':name', $name);
            $stmt->bindValue(':price', $price);
            $stmt->bindValue(':category', $category);
            $stmt->bindValue(':has_sizes', $hasSizes);
            $stmt->bindValue(':has_modifiers', $hasModifiers);
            $stmt->execute();
            
            // Delete old sizes and modifiers
            $stmt = $db->prepare('DELETE FROM product_sizes WHERE product_id = :id');
            $stmt->bindValue(':id', $id);
            $stmt->execute();
            
            $stmt = $db->prepare('DELETE FROM product_modifiers WHERE product_id = :id');
            $stmt->bindValue(':id', $id);
            $stmt->execute();
            
            // Insert new sizes
            foreach ($sizes as $size) {
                $sizeId = generateId();
                $stmt = $db->prepare('INSERT INTO product_sizes (id, product_id, size_name, price) 
                                      VALUES (:id, :product_id, :size_name, :price)');
                $stmt->bindValue(':id', $sizeId);
                $stmt->bindValue(':product_id', $id);
                $stmt->bindValue(':size_name', $size['name']);
                $stmt->bindValue(':price', floatval($size['price']));
                $stmt->execute();
            }
            
            // Insert new modifiers
            foreach ($modifiers as $modifier) {
                $modifierId = generateId();
                $stmt = $db->prepare('INSERT INTO product_modifiers (id, product_id, modifier_name, price) 
                                      VALUES (:id, :product_id, :modifier_name, :price)');
                $stmt->bindValue(':id', $modifierId);
                $stmt->bindValue(':product_id', $id);
                $stmt->bindValue(':modifier_name', $modifier['name']);
                $stmt->bindValue(':price', floatval($modifier['price']));
                $stmt->execute();
            }
            
            $db->exec('COMMIT');
            
            $product = getProductWithDetails($db, $id, $userId);
            jsonResponse(true, $product, 'Product updated successfully');
            
        } catch (Exception $e) {
            $db->exec('ROLLBACK');
            jsonResponse(false, null, $e->getMessage());
        }
        break;

    case 'DELETE':
        // Delete product
        $id = $_GET['id'] ?? $input['id'] ?? null;
        
        if (!$id) {
            jsonResponse(false, null, 'Product ID required');
        }
        
        // Verify ownership and delete (cascade will handle sizes and modifiers)
        $stmt = $db->prepare('DELETE FROM products WHERE id = :id AND user_id = :user_id');
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':user_id', $userId);
        
        if ($stmt->execute() && $db->changes() > 0) {
            jsonResponse(true, null, 'Product deleted successfully');
        } else {
            jsonResponse(false, null, 'Product not found or access denied');
        }
        break;

    default:
        jsonResponse(false, null, 'Method not allowed');
}

$db->close();

/**
 * Get product with sizes and modifiers
 */
function getProductWithDetails($db, $productId, $userId) {
    $stmt = $db->prepare('SELECT * FROM products WHERE id = :id AND user_id = :user_id');
    $stmt->bindValue(':id', $productId);
    $stmt->bindValue(':user_id', $userId);
    $result = $stmt->execute();
    $product = $result->fetchArray(SQLITE3_ASSOC);
    
    if (!$product) return null;
    
    // Get sizes
    $stmt = $db->prepare('SELECT id, size_name as name, price FROM product_sizes WHERE product_id = :id ORDER BY price');
    $stmt->bindValue(':id', $productId);
    $result = $stmt->execute();
    $sizes = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $sizes[] = $row;
    }
    $product['sizes'] = $sizes;
    
    // Get modifiers
    $stmt = $db->prepare('SELECT id, modifier_name as name, price FROM product_modifiers WHERE product_id = :id ORDER BY price');
    $stmt->bindValue(':id', $productId);
    $result = $stmt->execute();
    $modifiers = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $modifiers[] = $row;
    }
    $product['modifiers'] = $modifiers;
    
    return $product;
}

/**
 * Get all products with sizes and modifiers
 */
function getAllProductsWithDetails($db, $userId) {
    $stmt = $db->prepare('SELECT * FROM products WHERE user_id = :user_id ORDER BY name');
    $stmt->bindValue(':user_id', $userId);
    $result = $stmt->execute();
    
    $products = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $productId = $row['id'];
        
        // Get sizes
        $sizeStmt = $db->prepare('SELECT id, size_name as name, price FROM product_sizes WHERE product_id = :id ORDER BY price');
        $sizeStmt->bindValue(':id', $productId);
        $sizeResult = $sizeStmt->execute();
        $sizes = [];
        while ($sizeRow = $sizeResult->fetchArray(SQLITE3_ASSOC)) {
            $sizes[] = $sizeRow;
        }
        $row['sizes'] = $sizes;
        
        // Get modifiers
        $modStmt = $db->prepare('SELECT id, modifier_name as name, price FROM product_modifiers WHERE product_id = :id ORDER BY price');
        $modStmt->bindValue(':id', $productId);
        $modResult = $modStmt->execute();
        $modifiers = [];
        while ($modRow = $modResult->fetchArray(SQLITE3_ASSOC)) {
            $modifiers[] = $modRow;
        }
        $row['modifiers'] = $modifiers;
        
        $products[] = $row;
    }
    
    return $products;
}
?>
