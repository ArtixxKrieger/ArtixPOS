<?php
define('POS_ACCESS', true);
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = getInput();
$db = getDB();

// Verify user is logged in
$currentUser = getCurrentUser($db);
if (!$currentUser) {
    jsonResponse(false, null, 'Unauthorized - Please login');
}

$userId = $currentUser['id'];

switch ($method) {
    case 'GET':
        if (isset($_GET['analytics'])) {
            // Get sales analytics
            $startDate = $_GET['start'] ?? date('Y-m-d');
            $endDate = $_GET['end'] ?? date('Y-m-d');
            echo json_encode(['success' => true, 'data' => getAnalytics($db, $userId, $startDate, $endDate)]);
        } elseif (isset($_GET['date'])) {
            // Get sales by date
            $date = $_GET['date'];
            $stmt = $db->prepare('SELECT * FROM sales WHERE user_id = :user_id AND DATE(created_at) = :date ORDER BY created_at DESC');
            $stmt->bindValue(':user_id', $userId);
            $stmt->bindValue(':date', $date);
            $result = $stmt->execute();
            
            $sales = [];
            while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                $row['items'] = json_decode($row['items'], true);
                $sales[] = $row;
            }
            
            jsonResponse(true, $sales);
        } else {
            // Get all sales (limit to last 100)
            $limit = intval($_GET['limit'] ?? 100);
            $stmt = $db->prepare('SELECT * FROM sales WHERE user_id = :user_id ORDER BY created_at DESC LIMIT :limit');
            $stmt->bindValue(':user_id', $userId);
            $stmt->bindValue(':limit', $limit);
            $result = $stmt->execute();
            
            $sales = [];
            while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                $row['items'] = json_decode($row['items'], true);
                $sales[] = $row;
            }
            
            jsonResponse(true, $sales);
        }
        break;

    case 'POST':
        // Complete sale (move from pending to sales)
        $pendingId = $input['pending_id'] ?? null;
        
        if (!$pendingId) {
            jsonResponse(false, null, 'Pending order ID required');
        }
        
        // Get pending order - verify ownership
        $stmt = $db->prepare('SELECT * FROM pending_orders WHERE id = :id AND user_id = :user_id');
        $stmt->bindValue(':id', $pendingId);
        $stmt->bindValue(':user_id', $userId);
        $result = $stmt->execute();
        $order = $result->fetchArray(SQLITE3_ASSOC);
        
        if (!$order) {
            jsonResponse(false, null, 'Pending order not found');
        }
        
        // Insert into sales
        $id = generateId();
        $stmt = $db->prepare('INSERT INTO sales (id, user_id, items, subtotal, tax, discount, total, payment_method, payment_amount, change_amount, customer_name, notes) 
                              VALUES (:id, :user_id, :items, :subtotal, :tax, :discount, :total, :payment_method, :payment_amount, :change_amount, :customer_name, :notes)');
        
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':user_id', $userId);
        $stmt->bindValue(':items', $order['items']);
        $stmt->bindValue(':subtotal', $order['subtotal']);
        $stmt->bindValue(':tax', $order['tax']);
        $stmt->bindValue(':discount', $order['discount']);
        $stmt->bindValue(':total', $order['total']);
        $stmt->bindValue(':payment_method', $order['payment_method']);
        $stmt->bindValue(':payment_amount', $order['payment_amount']);
        $stmt->bindValue(':change_amount', $order['change_amount']);
        $stmt->bindValue(':customer_name', $order['customer_name']);
        $stmt->bindValue(':notes', $order['notes']);
        
        if ($stmt->execute()) {
            // Delete from pending
            $stmt = $db->prepare('DELETE FROM pending_orders WHERE id = :id AND user_id = :user_id');
            $stmt->bindValue(':id', $pendingId);
            $stmt->bindValue(':user_id', $userId);
            $stmt->execute();
            
            jsonResponse(true, ['id' => $id], 'Sale completed successfully');
        } else {
            jsonResponse(false, null, 'Failed to complete sale');
        }
        break;

    case 'DELETE':
        // Delete sale
        $id = $_GET['id'] ?? $input['id'] ?? null;
        
        if (!$id) {
            jsonResponse(false, null, 'Sale ID required');
        }
        
        $stmt = $db->prepare('DELETE FROM sales WHERE id = :id AND user_id = :user_id');
        $stmt->bindValue(':id', $id);
        $stmt->bindValue(':user_id', $userId);
        
        if ($stmt->execute() && $db->changes() > 0) {
            jsonResponse(true, null, 'Sale deleted successfully');
        } else {
            jsonResponse(false, null, 'Sale not found');
        }
        break;

    default:
        jsonResponse(false, null, 'Method not allowed');
}

$db->close();

/**
 * Get analytics data
 */
function getAnalytics($db, $userId, $startDate, $endDate) {
    // Get sales in date range
    $stmt = $db->prepare('SELECT * FROM sales WHERE user_id = :user_id AND DATE(created_at) >= :start AND DATE(created_at) <= :end ORDER BY created_at');
    $stmt->bindValue(':user_id', $userId);
    $stmt->bindValue(':start', $startDate);
    $stmt->bindValue(':end', $endDate);
    $result = $stmt->execute();
    
    $sales = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $row['items'] = json_decode($row['items'], true);
        $sales[] = $row;
    }
    
    $totalSales = count($sales);
    $totalRevenue = array_sum(array_column($sales, 'total'));
    $totalTax = array_sum(array_column($sales, 'tax'));
    $totalDiscount = array_sum(array_column($sales, 'discount'));
    
    // Hourly data for peak hours
    $hourlyData = array_fill(0, 24, 0);
    foreach ($sales as $sale) {
        $hour = intval(date('G', strtotime($sale['created_at'])));
        $hourlyData[$hour] += $sale['total'];
    }
    
    // Daily trend data
    $dailyData = [];
    foreach ($sales as $sale) {
        $date = date('Y-m-d', strtotime($sale['created_at']));
        if (!isset($dailyData[$date])) {
            $dailyData[$date] = 0;
        }
        $dailyData[$date] += $sale['total'];
    }
    
    // Payment methods breakdown
    $paymentMethods = [];
    foreach ($sales as $sale) {
        $method = $sale['payment_method'];
        if (!isset($paymentMethods[$method])) {
            $paymentMethods[$method] = ['count' => 0, 'amount' => 0];
        }
        $paymentMethods[$method]['count']++;
        $paymentMethods[$method]['amount'] += $sale['total'];
    }
    
    // Top selling products
    $productSales = [];
    foreach ($sales as $sale) {
        foreach ($sale['items'] as $item) {
            $name = $item['name'];
            if (!isset($productSales[$name])) {
                $productSales[$name] = ['quantity' => 0, 'revenue' => 0];
            }
            $productSales[$name]['quantity'] += $item['quantity'];
            $productSales[$name]['revenue'] += $item['total'];
        }
    }
    arsort($productSales);
    $topProducts = array_slice($productSales, 0, 10, true);
    
    return [
        'date_range' => ['start' => $startDate, 'end' => $endDate],
        'summary' => [
            'total_sales' => $totalSales,
            'total_revenue' => round($totalRevenue, 2),
            'total_tax' => round($totalTax, 2),
            'total_discount' => round($totalDiscount, 2),
            'average_order' => $totalSales > 0 ? round($totalRevenue / $totalSales, 2) : 0
        ],
        'hourly_data' => $hourlyData,
        'daily_data' => $dailyData,
        'payment_methods' => $paymentMethods,
        'top_products' => $topProducts
    ];
}
?>
