<?php
/**
 * Database Initialization Script
 * Run this to recreate the database with admin user and sample products
 */

define('POS_ACCESS', true);
require_once __DIR__ . '/../api/config.php';

echo "Initializing database...\n";

$db = getDB();

// Check if admin exists
$stmt = $db->prepare('SELECT id FROM users WHERE email = :email');
$stmt->bindValue(':email', 'admin@pos.local');
$result = $stmt->execute();
$admin = $result->fetchArray(SQLITE3_ASSOC);

if ($admin) {
    echo "Admin user already exists.\n";
} else {
    echo "Creating admin user...\n";
}

// Add sample products if none exist
$stmt = $db->prepare('SELECT COUNT(*) as count FROM products');
$result = $stmt->execute();
$count = $result->fetchArray(SQLITE3_ASSOC)['count'];

if ($count == 0) {
    echo "Adding sample products...\n";
    
    // Get admin ID
    $stmt = $db->prepare('SELECT id FROM users WHERE email = :email');
    $stmt->bindValue(':email', 'admin@pos.local');
    $result = $stmt->execute();
    $adminId = $result->fetchArray(SQLITE3_ASSOC)['id'];
    
    // Sample products with sizes
    $products = [
        ['name' => 'Brewed Coffee', 'basePrice' => 80, 'category' => 'Beverages', 'sizes' => [
            ['name' => 'Small', 'price' => 80],
            ['name' => 'Medium', 'price' => 100],
            ['name' => 'Large', 'price' => 120]
        ], 'modifiers' => [
            ['name' => 'Extra Shot', 'price' => 25],
            ['name' => 'Syrup', 'price' => 15]
        ]],
        ['name' => 'Ham Sandwich', 'basePrice' => 120, 'category' => 'Food', 'sizes' => [
            ['name' => 'Regular', 'price' => 120],
            ['name' => 'Large', 'price' => 150]
        ], 'modifiers' => [
            ['name' => 'Extra Cheese', 'price' => 30],
            ['name' => 'Extra Ham', 'price' => 40]
        ]],
        ['name' => 'Iced Tea', 'basePrice' => 60, 'category' => 'Beverages', 'sizes' => [
            ['name' => 'Small', 'price' => 60],
            ['name' => 'Medium', 'price' => 75],
            ['name' => 'Large', 'price' => 90]
        ], 'modifiers' => [
            ['name' => 'Extra Lemon', 'price' => 10],
            ['name' => 'Honey', 'price' => 15]
        ]],
        ['name' => 'French Fries', 'basePrice' => 70, 'category' => 'Food', 'sizes' => [
            ['name' => 'Small', 'price' => 70],
            ['name' => 'Medium', 'price' => 90],
            ['name' => 'Large', 'price' => 110]
        ], 'modifiers' => [
            ['name' => 'Cheese Dip', 'price' => 25],
            ['name' => 'Bacon Bits', 'price' => 35]
        ]]
    ];
    
    foreach ($products as $product) {
        $productId = generateId();
        
        // Insert product
        $stmt = $db->prepare('INSERT INTO products (id, user_id, name, price, category, has_sizes, has_modifiers) 
                              VALUES (:id, :user_id, :name, :price, :category, :has_sizes, :has_modifiers)');
        $stmt->bindValue(':id', $productId);
        $stmt->bindValue(':user_id', $adminId);
        $stmt->bindValue(':name', $product['name']);
        $stmt->bindValue(':price', $product['basePrice']);
        $stmt->bindValue(':category', $product['category']);
        $stmt->bindValue(':has_sizes', count($product['sizes']) > 0 ? 1 : 0);
        $stmt->bindValue(':has_modifiers', count($product['modifiers']) > 0 ? 1 : 0);
        $stmt->execute();
        
        // Insert sizes
        foreach ($product['sizes'] as $size) {
            $sizeId = generateId();
            $stmt = $db->prepare('INSERT INTO product_sizes (id, product_id, size_name, price) 
                                  VALUES (:id, :product_id, :name, :price)');
            $stmt->bindValue(':id', $sizeId);
            $stmt->bindValue(':product_id', $productId);
            $stmt->bindValue(':name', $size['name']);
            $stmt->bindValue(':price', $size['price']);
            $stmt->execute();
        }
        
        // Insert modifiers
        foreach ($product['modifiers'] as $modifier) {
            $modId = generateId();
            $stmt = $db->prepare('INSERT INTO product_modifiers (id, product_id, modifier_name, price) 
                                  VALUES (:id, :product_id, :name, :price)');
            $stmt->bindValue(':id', $modId);
            $stmt->bindValue(':product_id', $productId);
            $stmt->bindValue(':name', $modifier['name']);
            $stmt->bindValue(':price', $modifier['price']);
            $stmt->execute();
        }
    }
    
    echo "Sample products added!\n";
} else {
    echo "Products already exist: $count products found.\n";
}

echo "Database initialization complete!\n";
echo "\nAdmin credentials:\n";
echo "Email: admin@pos.local\n";
echo "Password: admin123\n";

$db->close();
?>
