<?php
define('POS_ACCESS', true);
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$input = getInput();
$db = getDB();

// Verify admin access
$currentUser = getCurrentUser($db);
if (!$currentUser || $currentUser['role'] !== 'admin') {
    jsonResponse(false, null, 'Unauthorized - Admin access required');
}

switch ($method) {
    case 'GET':
        // List all clients
        $stmt = $db->query('SELECT id, email, name, store_name, role, is_active, created_at, last_login FROM users WHERE role = "client" ORDER BY created_at DESC');
        $clients = [];
        while ($row = $stmt->fetchArray(SQLITE3_ASSOC)) {
            $clients[] = $row;
        }
        jsonResponse(true, $clients);
        break;
        
    case 'PUT':
        // Update client (toggle active status)
        $clientId = $input['id'] ?? null;
        $isActive = $input['is_active'] ?? null;
        
        if (!$clientId) {
            jsonResponse(false, null, 'Client ID required');
        }
        
        // Prevent modifying admin
        $stmt = $db->prepare('SELECT role FROM users WHERE id = :id');
        $stmt->bindValue(':id', $clientId);
        $result = $stmt->execute();
        $client = $result->fetchArray(SQLITE3_ASSOC);
        
        if (!$client) {
            jsonResponse(false, null, 'Client not found');
        }
        
        if ($client['role'] === 'admin') {
            jsonResponse(false, null, 'Cannot modify admin account');
        }
        
        $stmt = $db->prepare('UPDATE users SET is_active = :active WHERE id = :id');
        $stmt->bindValue(':active', $isActive ? 1 : 0);
        $stmt->bindValue(':id', $clientId);
        
        if ($stmt->execute()) {
            $status = $isActive ? 'activated' : 'deactivated';
            jsonResponse(true, null, "Client {$status} successfully");
        } else {
            jsonResponse(false, null, 'Failed to update client');
        }
        break;
        
    case 'DELETE':
        // Delete client
        $clientId = $_GET['id'] ?? $input['id'] ?? null;
        
        if (!$clientId) {
            jsonResponse(false, null, 'Client ID required');
        }
        
        // Prevent deleting admin
        $stmt = $db->prepare('SELECT role FROM users WHERE id = :id');
        $stmt->bindValue(':id', $clientId);
        $result = $stmt->execute();
        $client = $result->fetchArray(SQLITE3_ASSOC);
        
        if (!$client) {
            jsonResponse(false, null, 'Client not found');
        }
        
        if ($client['role'] === 'admin') {
            jsonResponse(false, null, 'Cannot delete admin account');
        }
        
        $stmt = $db->prepare('DELETE FROM users WHERE id = :id');
        $stmt->bindValue(':id', $clientId);
        
        if ($stmt->execute()) {
            jsonResponse(true, null, 'Client deleted successfully');
        } else {
            jsonResponse(false, null, 'Failed to delete client');
        }
        break;
        
    default:
        jsonResponse(false, null, 'Method not allowed');
}

$db->close();
?>
